/*
*  Copyright ( C ) 1994-2006 ZyXEL Communications, Corp.
*  All Rights Reserved.
*
* ZyXEL Confidential; Need to Know only.vi
* Protected as an unpublished work.
*
* The computer program listings, specifications and documentation
* herein are the property of ZyXEL Communications, Corp. and
* shall not be reproduced, copied, disclosed, or used in whole or
* in part for any reason without the prior express written permission of
* ZyXEL Communications, Corp.
*/


#ifndef	ZYACCESS_H
#define	ZYACCESS_H

int checkShareAccessRight(char* username, char *password, char *sharePath, char *authority);
int checkShareAccessRightOnce(char* username, char *password, char *sharePath, char *authority);  /* for daemon-type process to use */
int checkShareAccessRightAndListOnce(char* username, char *password, char *sharePath, char *authority, char* tempFile);  /* for daemon-type process to use, and get a file list */

/*Checks the permission of all shares in shareArray and record the result in validIndex.*/
int checkShareAccessRightBunch(char* username, char *password, char **shareArray, char *authority, int* validIndex, int shareNum);
int getAvailShareList(char *username, char *password, char **shares, int *permissionList);

#endif
