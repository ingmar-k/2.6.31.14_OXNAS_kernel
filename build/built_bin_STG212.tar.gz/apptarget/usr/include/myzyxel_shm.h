
#define SHMKEY ((key_t) 33778)

#define SHM_PATH	"/usr/sbin/reg_agent"
#define MSQ_PATH	"/usr/sbin/check_agent"
#define PROC_MRD 	"/proc/MRD"

#define MAX_STR_LEN	64

/* data structure for share memory */
struct shared_use_st {	
	int cf_active;
	int cf_report;	
	int immed_flag;	//represent whether send daily-check message
	char	username[MAX_STR_LEN];
	char	password[MAX_STR_LEN];
	int 	reg_status;	//0:device not registered. 1:device registered
	int	flag;	//expiration check fail flag. 1: check fail
	int	selfCheckHr;	
	int	idp_day;	
	int 	idp_type;	//1:trial, 2:standard
	int	as_day;	
	int 	as_type;	//1:trial, 2:standard
	int	av_day;	
	int 	av_type;	//1:trial, 2:standard
	int	cf_day;	
	int 	cf_type;	//1:trial, 2:standard
};




