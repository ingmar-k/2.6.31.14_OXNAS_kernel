/* $Id: zylog.h,v 1.62 2006/02/16 11:14:51 lachang Exp $ */

/*
 * $Log: zylog.h,v $
 * Revision 1.62  2006/02/16 11:14:51  lachang
 * modify firewall VRPT format
 *
 * Revision 1.61  2006/02/16 06:16:47  eddieho
 * SHOW category was removed.
 *
 * Revision 1.60  2006/01/24 01:54:01  peterwang
 * add zylog definition for Force User Authentication
 *
 * Revision 1.59  2006/01/03 05:00:18  lachang
 * change the data type of log_num
 *
 * Revision 1.58  2005/12/06 08:52:42  lachang
 * fix GUI "sending-now" behavior
 *
 * Revision 1.57  2005/11/25 09:56:35  lachang
 * add semphore debug imformation
 *
 * Revision 1.55  2005/10/06 06:55:08  eddieho
 * ZYLOG_SRC_SHOW & ZYLOG_FAC_SHOW were added.
 *
 * Revision 1.54  2005/09/27 09:11:11  edward
 * make content filter forward logs another category
 *
 * Revision 1.53  2005/09/15 07:55:11  saxont
 * add port-grouping
 *
 * Revision 1.52  2005/09/07 14:41:56  kl.chiang
 * add dynamic route
 *
 * Revision 1.51  2005/09/07 13:25:12  saxont
 * add interface and account
 *
 * Revision 1.50  2005/09/07 06:29:44  lachang
 * add ZYLOG_MAILMAN_BIN
 *
 * Revision 1.49  2005/09/07 05:33:50  hwtseng
 * add PKI LOG
 *
 * Revision 1.48  2005/09/05 06:18:12  rogerho
 * add ZYLOG_SRC_NAT,ZYLOG_FAC_NAT
 *
 * Revision 1.47  2005/08/29 09:41:00  peterwang
 * add ZYLOG_SRC_DEVICE_HA
 *
 * Revision 1.46  2005/08/29 08:27:20  edward
 * support enable/disable log suppression
 *
 * Revision 1.45  2005/08/24 12:53:38  herenlin
 * modify for ftp file manage
 *
 * Revision 1.44  2005/08/23 08:35:24  lachang
 * add "log filter && log persistent"
 *
 * Revision 1.43  2005/08/23 01:35:35  edward
 * change console device to ttyS0
 *
 * Revision 1.42  2005/08/19 07:28:14  rogerho
 * add connectivity check facility and source
 *
 * Revision 1.41  2005/08/15 06:18:46  fannyk
 * replace command notation
 *
 * Revision 1.40  2005/08/15 06:17:23  fannyk
 * replace command notation.
 *
 * Revision 1.39  2005/08/09 07:02:09  lachang
 * omit mail server && syslog server config ordering
 *
 * Revision 1.38  2005/08/08 09:00:53  fannyk
 * add ZYLOG_SRC_SYSTEM/ZYLOG_FAC_SYSTEM for ntp update
 *
 * Revision 1.37  2005/08/01 12:55:58  eddieho
 * ZYLOG_SRC_POLICY_ROUTE & ZYLOG_FAC_POLICY_ROUTE were added.
 *
 * Revision 1.36  2005/07/27 12:40:41  shunchao
 * log the built-in service access denied
 *
 * Revision 1.35  2005/07/26 03:17:58  lachang
 * add "mail size limit"
 *
 * Revision 1.34  2005/07/14 02:11:43  lachang
 * add csum
 *
 * Revision 1.33  2005/07/05 08:52:05  lachang
 * zylog-enhancement
 *
 */

#ifndef _ZYLOG_H
#define _ZYLOG_H

#include <stdio.h>
#include <stdint.h>
#include <time.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <syslog.h>

#include <regex.h>

/* protocol ID for zyklog (kernel log) */
#define NETLINK_ZYKLOG		28

/* log system parameters */
#define ZYLOG_MAIL_SIZE				1048576
#define ZYLOG_SYSTEM_LOG_NUM		512
#define ZYLOG_DEBUG_LOG_NUM			1024

#define ZYLOG_MAX_PATH_LEN		256
#define ZYLOG_MAX_MESSAGE_LEN		1024
#define ZYLOG_MAX_NOTE_LEN			32
#define ZYLOG_MAX_USERNAME_LEN		32

#define ZYLOG_MAIL_NUM				2
#define ZYLOG_REMOTE_SERVER_NUM		4

#define ZYLOG_SYSTEM_SUPPRESS_INTERVAL	10
#define ZYLOG_DEBUG_SUPPRESS_INTERVAL	10

#define ZYLOG_MAX_CONSOLIDATION_COUNT	255
#define ZYLOG_MAX_MSMTP_COUNT 100	/* maximum msmtp process */

#define ZYLOG_REMOTE_SERVER_FIFO_NAME	"/tmp/zylog_fifo"	/* default name for syslog-ng fifo */
#define ZYLOG_CONSOLE_DEVICE			"/dev/ttyS0"
#define ZYLOGD_PID_FILE					"/var/run/zylogd.pid"

#define ZYLOG_MAIL_TEMP_DIR				"/tmp/"
#define ZYLOG_MAIL_EVENT_FILE			"event"
#define ZYLOG_MAIL_ALERT_FILE			"alert"

#define ZYLOG_MSMTP_BIN					"/usr/sbin/msmtp"
#define ZYLOG_MSMTP_RC					"/etc/msmtprc"
#define ZYLOG_MSMTP_RC_RECV				"/etc/msmtprc_recv"
#define ZYLOG_MSMTP_RC_TMP				"/tmp/msmtprc.tmp"
#define ZYLOG_MSMTP_TIMEOUT				10

#define ZYLOG_FLAGS_LOOKUP_USER			(1 << 0)
#define ZYLOG_FLAGS_NO_SUPPRESSION		(1 << 1)



/* priority */
#define ZYLOG_PRI_EMERG		LOG_EMERG           /* system is unusable */
#define ZYLOG_PRI_ALERT		LOG_ALERT           /* action must be taken immediately */
#define ZYLOG_PRI_CRIT		LOG_CRIT            /* critical conditions */
#define ZYLOG_PRI_ERR		LOG_ERR             /* error conditions */
#define ZYLOG_PRI_WARNING	LOG_WARNING         /* warning conditions */
#define ZYLOG_PRI_NOTICE	LOG_NOTICE          /* normal but significant condition */
#define ZYLOG_PRI_INFO		LOG_INFO            /* informational */
#define ZYLOG_PRI_DEBUG		LOG_DEBUG           /* debug-level messages */

#define ZYLOG_EVENT_LOG_LEVEL			ZYLOG_PRI_INFO
#define ZYLOG_DEBUG_LOG_LEVEL			ZYLOG_PRI_DEBUG
#define ZYLOG_ALERT_LEVEL				ZYLOG_PRI_CRIT

#define ZYLOG_CONSOLE_LEVEL				ZYLOG_PRI_EMERG

/* keys */
#define ZYLOG_LOCK_KEY		0x12340001
#define ZYLOG_BUFFER_KEY	0x12340002
#define ZYLOG_MESSAGE_QUEUE_KEY 0x12340003

/* for debugging */
#ifdef ENABLE_ZYLOG_DEBUG
#define ZYLOG_DEBUG(fmt, args...)	fprintf(stderr, "%s %s: " fmt, __FILE__, __FUNCTION__, ##args)
#else
#define ZYLOG_DEBUG(fmt, args...)
#endif

/* for log persistence */
/* keep log file on /etc not /etc/zyxel because 210 has limited /etc/zyxel size */
#define BACK 		"/etc/backup"
#define BACK_DEBUG 	"/etc/backup1"






/* structures */
struct zylog_buffer {
	int     shmid;
	void    *addr;
	key_t   key;
};

/* log sources */
enum zylog_sources {
	ZYLOG_SRC_DEFAULT = 0,	/* Don't touch */

	ZYLOG_SRC_CONTENT_FILTER,
	ZYLOG_SRC_CONTENT_FILTER_FORWARD,
	ZYLOG_SRC_UAM,
	ZYLOG_SRC_MYZYXEL_DOT_COM,
	ZYLOG_SRC_ZYSH,				/* 5 */
	ZYLOG_SRC_IDP,
	ZYLOG_SRC_AS,
	ZYLOG_SRC_TRAFFIC,
	ZYLOG_SRC_FILE_MANAGE,
	ZYLOG_SRC_APP_PATROL,
	ZYLOG_SRC_IKE,
	ZYLOG_SRC_IPSEC,
	ZYLOG_SRC_FIREWALL,
	ZYLOG_SRC_SESSIONS_LIMIT,
	ZYLOG_SRC_AV,
	ZYLOG_SRC_POLICY_ROUTE,
	ZYLOG_SRC_BUILTIN_SERVICE,	/* 17 */
	ZYLOG_SRC_SYSTEM,			/* 18 */
	ZYLOG_SRC_CONNECTIVITY_CHECK,
	ZYLOG_SRC_DEVICE_HA,
	ZYLOG_SRC_ROUTING_PROTOCOL,
	ZYLOG_SRC_NAT,
	ZYLOG_SRC_PKI,
	ZYLOG_SRC_INTERFACE,
	ZYLOG_SRC_ISP_ACCOUNT,
	ZYLOG_SRC_PORT_GROUPING,
	ZYLOG_SRC_FORCE_AUTH,
	ZYLOG_SRC_STORAGE,		/* ymtseng.20060728: new category 'storage', 28 */
	ZYLOG_SRC_NSA_SHARE,	/* emma.20070104: new category 'share', 29 */
	ZYLOG_SRC_APPLICATION,	/* France add: source for open source, 30 */
	ZYLOG_SRC_BACKUP,		/* France add: backup for backup, restore, snapshot, 31 */
	ZYLOG_SRC_AUTOUPLOAD,	/* France add: file auto-upload, 32 */
	ZYLOG_SRC_ACTIONLOG,	/* Chorus add: add action-log */

	ZYLOG_SRC_LIMIT		/* Don't touch */
};


/* log facility */
enum zylog_facilities {
	ZYLOG_FAC_DEFAULT = 0,	/* Don't touch */

	ZYLOG_FAC_CONTENT_FILTER,
	ZYLOG_FAC_CONTENT_FILTER_FORWARD,
	ZYLOG_FAC_UAM,
	ZYLOG_FAC_MYZYXEL_DOT_COM,
	ZYLOG_FAC_ZYSH,
	ZYLOG_FAC_IDP,
	ZYLOG_FAC_AS,
	ZYLOG_FAC_TRAFFIC,
	ZYLOG_FAC_FILE_MANAGE,
	ZYLOG_FAC_APP_PATROL,
	ZYLOG_FAC_IKE,
	ZYLOG_FAC_IPSEC,
	ZYLOG_FAC_FIREWALL,
	ZYLOG_FAC_SESSIONS_LIMIT,
	ZYLOG_FAC_AV,
	ZYLOG_FAC_POLICY_ROUTE,
	ZYLOG_FAC_BUILTIN_SERVICE,
	ZYLOG_FAC_SYSTEM,
	ZYLOG_FAC_CONNECTIVITY_CHECK,
	ZYLOG_FAC_DEVICE_HA,
	ZYLOG_FAC_ROUTING_PROTOCOL,
	ZYLOG_FAC_NAT,
	ZYLOG_FAC_PKI,
	ZYLOG_FAC_INTERFACE,
	ZYLOG_FAC_ISP_ACCOUNT,
	ZYLOG_FAC_PORT_GROUPING,
	ZYLOG_FAC_FORCE_AUTH,
	ZYLOG_FAC_STORAGE,		/* ymtseng.20060728: new category 'storage' */
	ZYLOG_FAC_NSA_SHARE,	/* emma.20070104: new category 'share' */
	ZYLOG_FAC_APPLICATION,	/* France add: source for open source */
	ZYLOG_FAC_BACKUP,		/* France add: backup for backup, restore, snapshot */
	ZYLOG_FAC_AUTOUPLOAD,	/* France add: file auto-upload */
	ZYLOG_FAC_ACTIONLOG,	/* Chorus add: action log */

	ZYLOG_FAC_LIMIT		/* Don't touch */
};

/* define zylog error number */
enum {
	ZYLOG_ESYSERROR = 1,
	ZYLOG_EEXIST,
	ZYLOG_EIDRM,
	ZYLOG_EINTR,

	/* return value */
	ZYLOG_EGETSEM,
	ZYLOG_EGETRING,
	ZYLOG_EATTRING,
	ZYLOG_ELOCK
};


/* lock structure */
struct zylog_lock {
	int     semid;
	key_t   key;
};

struct traffic_log {
	uint32_t duration;
	uint32_t sent;
	uint32_t received;
	char dir[16];
	uint16_t proto;
	char proto_name[16];
};

struct idp_log {
	char class[32];
	char act[16];
	uint32_t sid;
	char ob[16];
	char ob_mac[16];
};

struct firewall_log {
	char class[32];
	char ob[16];
	char ob_mac[16];
	char dir[16];
	uint16_t proto;
	char proto_name[16];
};

/* ZLD centralized log structures */
struct zylog_entry {
	/* fields to judge duplicated log  */
	uint32_t srcip, dstip;
	uint16_t sport, dport;

	char message[ZYLOG_MAX_MESSAGE_LEN];
	char note[ZYLOG_MAX_NOTE_LEN];
	char username[ZYLOG_MAX_USERNAME_LEN];

	union {
		struct traffic_log traffic;
		struct idp_log idp;
		struct firewall_log firewall;
	} u;

	/* don't change it */
	uint8_t source;
	uint8_t facility;
	uint8_t priority;
	uint8_t __padding;	/* necessary for log consolidation */

	/* varied parts */
	uint32_t timestamp;
	struct timeval s_tm;
	unsigned short count;
	int need_mail:ZYLOG_MAIL_NUM,	/* reserve ZYLOG_MAIL_NUM bits */
		 force_alert:1,
		 debug:1,
		 no_suppress:1;
	uint32_t csum;
};

typedef struct zylog_event {
	long int my_msg_type;
	uint32_t srcip, dstip;
	uint16_t sport, dport;
	char message[ZYLOG_MAX_MESSAGE_LEN];
	char note[ZYLOG_MAX_NOTE_LEN];
	uint8_t source;
	uint8_t facility;
	uint8_t priority;
}ZYLOG_EVENT;

enum config_type {
	CONFIG_TYPE_SYSTEM,
	CONFIG_TYPE_MAIL,
	CONFIG_TYPE_CONSOLE,
	CONFIG_TYPE_REMOTE_SERVER,
	CONFIG_TYPE_MISC,
	CONFIG_TYPE_MAX
};

enum config_item {
	/* common items */
	CONFIG_ITEM_ALL,
	CONFIG_ITEM_ACTIVE,
	CONFIG_ITEM_ENABLE,
	CONFIG_ITEM_LOGGING_CATEGORY,

	/* specified items */
	CONFIG_ITEM_SERVER,
	CONFIG_ITEM_SUBJECT,
	CONFIG_ITEM_SENDER,
	CONFIG_ITEM_LOG_RECEIVER,
	CONFIG_ITEM_ALERT_RECEIVER,
	CONFIG_ITEM_AUTH_ACTIVE,
	CONFIG_ITEM_AUTH_ENABLE,
	CONFIG_ITEM_AUTH_NAME_PASSWORD,
	CONFIG_ITEM_SCHEDULE,
	CONFIG_ITEM_FORMAT,
	CONFIG_ITEM_FACILITY,
	CONFIG_ITEM_ENABLE_SYSTEM_SUPPRESS,
	CONFIG_ITEM_SYSTEM_SUPPRESS_INTERVAL,
	CONFIG_ITEM_ENABLE_DEBUG_SUPPRESS,
	CONFIG_ITEM_DEBUG_SUPPRESS_INTERVAL,
	CONFIG_ITEM_USE_HTML_FORMAT,
        CONFIG_ITEM_ALERT_PRI		/* priority for alert log */
};

/* definition for zylog mail */
#define ZYLOG_MAILMAN_BIN 	"/usr/sbin/zylog_mailman"
#define MAIL_WHEN_FULL		0
#define MAIL_HOURLY			1
#define MAIL_DAILY			2
#define MAIL_WEEKLY			3

#define BIT_MAIL_LOG		1
#define BIT_MAIL_ALERT		2

#define MAIL_PROCESS_COUNT 0
#define MAIL_SIZE 1

struct zylog_mail {
	char active;
	char enable;
	char is_html;
	char alert_pri; /* France: priority for alert mail */

	char server[64];
	char subject[64];

	char sender[64];
	char log_receiver[64];
	char alert_receiver[64];

	char auth_active;
	char auth_enable;
	char auth_name[32];
	char auth_password[32];

	char schedule;
	char day, hour, minute;

	char logging_category[ZYLOG_SRC_LIMIT];
};

/* definition for system buffer and remote server */
#define DISABLE_LOG						0
#define ENABLE_LOG						1
#define ENABLE_DEBUG_LOG				2
#define ENABLE_ALERT_LOG				3

#define REMOTE_SERVER_FORMAT_VRPT		0

enum remote_server_facility {
	REMOTE_SERVER_FACILITY_LOCAL1 = 17,
	REMOTE_SERVER_FACILITY_LOCAL2,
	REMOTE_SERVER_FACILITY_LOCAL3,
	REMOTE_SERVER_FACILITY_LOCAL4,
	REMOTE_SERVER_FACILITY_LOCAL5,
	REMOTE_SERVER_FACILITY_LOCAL6,
	REMOTE_SERVER_FACILITY_LOCAL7
};

struct zylog_remote_server {
	char active;
	char enable;

	char server[64];

	char format;
	char facility;

	char logging_category[ZYLOG_SRC_LIMIT];
};

struct zylog_system {
	char logging_category[ZYLOG_SRC_LIMIT];
};

struct zylog_console {
	char active;
	char logging_category[ZYLOG_SRC_LIMIT];
};

struct zylog_config {
	struct zylog_system system;
	struct zylog_console console;
	struct zylog_mail mail[ZYLOG_MAIL_NUM];
	struct zylog_remote_server server[ZYLOG_REMOTE_SERVER_NUM];

	int enable_system_suppress;
	int system_suppress_interval;
	int enable_debug_suppress;
	int debug_suppress_interval;
};

#define LOG_TYPE_SYSTEM			0
#define LOG_TYPE_DEBUG			1
/* for log persistence */
#define LOG_TYPE_SYSTEM_LAST	2
#define LOG_TYPE_DEBUG_LAST 	3


/* ZyLog Return Codes */
#define ZYLOG_OK		0
#define ZYLOG_ERR		-1
#define ZYLOG_DB_ERR	-2


struct zylog_centralized_log {
	struct zylog_entry system_entry[ZYLOG_SYSTEM_LOG_NUM];
	struct zylog_entry debug_entry[ZYLOG_DEBUG_LOG_NUM];

	u_int64_t system_entry_num;
	u_int64_t debug_entry_num;

	unsigned long mail_sequence[ZYLOG_MAIL_NUM];
	unsigned long mail_size;
	int mail_process_count;

	struct zylog_config config;
	pid_t pid;
	char cmdline[64];
	int fail_count;
	int fail_pid;
};

struct zylog_identifier {
	char *zysh_name;
	char *category_name;
	char *pattern;

	int source;
	int facility;

	regex_t re;
};

extern struct zylog_identifier zylog_id[];
extern int zylog_errno;

/* exported functions */
extern int zylog_get_entry_file(char log_type, u_int64_t total, unsigned int which, struct zylog_entry *entry);
extern u_int64_t zylog_get_current_num(char log_type);
extern u_int64_t zylog_get_current_num_file(char log_type);
extern int zylog_get_entry(char log_type, u_int64_t current,
		unsigned int offset, struct zylog_entry *entry);
extern int save_log(int flag);

extern int zylog(int src, int pri, int fac,
	   	u_int32_t srcip, u_int16_t srcport, u_int32_t dstip,u_int16_t dstport,
		char *note, const char *fmt, ...);
extern int zylog_message_queue(int src, int pri, int fac,
	   	u_int32_t srcip, u_int16_t srcport, u_int32_t dstip,u_int16_t dstport,
		char *note, const char *fmt, ...);
extern int zylog2(struct zylog_entry *entry, int flags);
extern int zylog_clear_log(char log_type);
extern void transform_iso_time_to_month(time_t timestamp, char *tp);
extern int zylog_mail_event(int which, int send_all);
extern int zylog_set_config(int type, int which, int item, void *args);
extern int zylog_get_config(int type, int which, int item, void *args);

extern int zylog_init(void);
extern int zylog_exit(void);
extern int zylog_print_debug(void);
extern int zylog_reset(void);
extern int zylog_mail_inc(int type, unsigned long amount);
extern int zylog_mail_dec(int type, unsigned long amount);

/* internal functions */
extern int zylog_create_buffer(struct zylog_buffer *buffer,
		key_t key, unsigned int size);
extern int zylog_init_buffer(struct zylog_buffer *buffer, key_t key);
extern int zylog_attach_buffer(struct zylog_buffer *buffer);
extern int zylog_detach_buffer(struct zylog_buffer *buffer);
extern int zylog_remove_buffer(struct zylog_buffer *buffer);
extern int zylog_create_lock(struct zylog_lock *lock, key_t key, int val);
extern int zylog_init_lock(struct zylog_lock *lock, key_t key);
extern int zylog_get_lock_val(struct zylog_lock *lock);
extern int zylog_set_lock_val(struct zylog_lock *lock, int val);
extern int zylog_dolock(struct zylog_lock *lock);
extern int zylog_unlock(struct zylog_lock *lock);
extern int zylog_notify_lock(struct zylog_lock *lock);
extern int zylog_remove_lock(struct zylog_lock *lock);
extern char* zylog_transfer_category(int source);
extern char* zylog_transfer_severity(int priority);
extern void init_zylog_identifier(void);
extern void fini_zylog_identifier(void);
extern struct zylog_identifier *zylog_getid_by_pattern(char *pattern);
extern struct zylog_identifier *zylog_getid_by_source (int source);

#endif

/* vi:set sw=4 ts=4: */
