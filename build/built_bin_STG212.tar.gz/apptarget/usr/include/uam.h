/* $Id: uam.h,v 1.22 2006/02/09 09:15:04 edward Exp $ */

/*
 * $Log: uam.h,v $
 * Revision 1.22  2006/02/09 09:15:04  edward
 * enlarge the size of auth token
 *
 * Revision 1.21  2005/11/15 05:51:01  edward
 * show failed login reason for web login
 *
 * Revision 1.20  2005/09/12 08:12:18  edward
 * allow more people share the same account
 *
 * Revision 1.19  2005/09/08 08:38:25  edward
 * alter some generic codes for other pam modules
 *
 * Revision 1.18  2005/08/23 07:37:27  edward
 * adjust length of unique
 *
 * Revision 1.17  2005/08/18 08:29:01  edward
 * support update lease automation
 *
 * Revision 1.16  2005/08/17 08:17:48  edward
 * support user idle detection
 *
 * Revision 1.15  2005/08/10 01:17:05  edward
 * update definition/wording
 *
 * Revision 1.14  2005/08/08 12:47:39  edward
 * support external virtual users
 *
 * Revision 1.13  2005/07/29 05:24:29  edward
 * make wording more readable
 *
 * Revision 1.12  2005/07/28 10:41:46  edward
 * add user login uniqueness support and change definition wording
 *
 * Revision 1.11  2005/07/28 01:58:25  edward
 * add user lock support
 *
 * Revision 1.10  2005/07/13 00:51:34  edward
 * add debug option and fix bugs of userdb handling
 *
 * Revision 1.9  2005/05/06 07:09:37  edward
 * add notify function to uam library
 *
 * Revision 1.8  2005/04/19 09:53:55  edward
 * support login privilege matrix
 *
 * Revision 1.7  2005/03/30 09:54:25  edward
 * split uam library out: add uamlog.h
 *
 * Revision 1.6  2005/03/15 06:07:27  edward
 * add user log support
 *
 * Revision 1.5  2005/03/03 00:59:02  edward
 * add user attribute for an uam notify event
 *
 * Revision 1.4  2005/02/15 05:02:19  edward
 * add idle timeout definition for backward compatibility
 *
 * Revision 1.3  2005/02/04 07:12:28  edward
 * add user profile and multi-login support
 *
 * Revision 1.2  2004/12/24 06:28:31  edward
 * update event name
 *
 * Revision 1.1.1.1  2004/12/23 06:28:24  edward
 * initial release
 *
 */

#ifndef _UAM_H_
#define _UAM_H_

#include <stdint.h>
#include <sys/types.h>

#include "list.h"
#include "spec.h"

/* open for user-aware applications */
#define UAM_SERVICE_LEN		16
#define UAM_USERNAME_LEN	32
#define UAM_UNIQUE_LEN		64

#ifdef ENABLE_SAMBA
#define UAM_PASSWORD_LEN	64
#endif /* ENABLE SAMBA */

/* PAM_ZYXEL_ERRNO was defined in pam-0.76/libpam/include/security/_pam_types.h
   but moved here to avoid changing to GPL file
 */
#ifndef PAM_ZYXEL_ERRNO
#define PAM_ZYXEL_ERRNO     11 /* zyxel authentication errno */
#endif

struct uam_handle
{
	int fd;

#define UAM_MODE_QUERY		0
#define UAM_MODE_LISTEN		1
	u_int8_t mode;
};

/* events */
enum event_number {
	/* exported event */
	UAM_EVENT_USER_LOGIN = 1,
	UAM_EVENT_USER_LOGOUT,
	UAM_EVENT_USER_REAUTH_TIMEOUT,
	UAM_EVENT_USER_LEASE_TIMEOUT,
	UAM_EVENT_USER_IDLE_TIMEOUT,
	UAM_EVENT_QUERY_RESULT,
	UAM_EVENT_USER_TRAFFIC,

	/* update event */
	UAM_EVENT_UPDATE_LEASE_TIME,

	/* internal events */
	UAM_EVENT_USER_ALIVE,
	UAM_EVENT_APP_QUERY_NAME,
	UAM_EVENT_APP_QUERY_FROM,
	UAM_EVENT_APP_QUERY_ALL,
	UAM_EVENT_APP_LISTEN,
	UAM_EVENT_APP_CLOSE,
	UAM_EVENT_TIMER_SECOND,
	UAM_EVENT_TIMER_10SECONDS,
	UAM_EVENT_CONFIG_CHANGE,
	UAM_EVENT_LIMIT,
};

struct uam_event
{
	int event;
	int count;
	int reauth_time;
	int lease_time;

	/* field to identify a user */
	char service[UAM_SERVICE_LEN];
	char username[UAM_USERNAME_LEN];
#ifdef ENABLE_SAMBA
	char password[UAM_PASSWORD_LEN];
#endif /* ENABLE SAMBA */
	char real_username[UAM_USERNAME_LEN];
	char unique[UAM_UNIQUE_LEN + 1];
	u_int32_t ip;

#define UAM_USER_ATTRIBUTE_MANAGEMENT	(1 << 0)
#define UAM_USER_ATTRIBUTE_ACCESS		(1 << 1)
	unsigned char attribute;
	unsigned char type;

	/* field to update */
	union {
		unsigned int lease_time;
	} update;
};

struct uam_request
{
#define UAM_QUERY_NAME	1
#define UAM_QUERY_FROM	2

#define UAM_QUERY_ALL	3
#define UAM_LISTEN		4
	int method;

	union {
		char username[UAM_USERNAME_LEN];
		u_int32_t ip;
	} u;

};

struct uam_response
{
#define UAM_RESPONSE_SUCCESS	0
#define UAM_RESPONSE_FAIL		1
	int code;
};

struct user_info
{
	char service[UAM_SERVICE_LEN];
	char username[UAM_USERNAME_LEN];			/* login username */
#ifdef ENABLE_SAMBA
	char password[UAM_PASSWORD_LEN];
#endif /* ENABLE SAMBA */
	char virtual_username[UAM_USERNAME_LEN];	/* the username for ACL rules */
	char unique[UAM_UNIQUE_LEN + 1];
	u_int32_t ip;

	/* seconds since boot */
	unsigned long login_time;
	unsigned long lease_time;
	unsigned long reauth_time;
	unsigned long idle_time;

	/* user profile field*/
	unsigned int lease_minute;
	unsigned int reauth_minute;
	unsigned int access;
	unsigned int visibility;

	unsigned char attribute;
	unsigned char type;
};

struct uam_handle *uam_create_handle(u_int32_t flags);

int uam_set_mode(struct uam_handle *h, u_int8_t mode);

int uam_send_query(struct uam_handle *h, struct uam_request *request);

int uam_read_event(struct uam_handle *h, struct uam_event *event,
					int timeout);

int uam_read_data(struct uam_handle *h, struct uam_event *event,
					struct user_info *info);

int uam_destroy_handle(struct uam_handle *h);

void uam_perror(const char *s);

char *uam_errstr(void);

/* utilities */
int
uam_find_first_match(struct user_info *info, char *service, char *username,
					 u_int32_t ip, char *unique);
int uam_notify_login(char *s, char *u, u_int32_t ip, char *q);
int uam_notify_logout(char *s, char *u, u_int32_t ip, char *q);
int uam_notify_update_lease(char *s, char *u, u_int32_t ip, char *q, int l);

/* internal use */
/* for service mapping */
#define SERVICE_NAME_CONSOLE		"console"
#define SERVICE_NAME_TELNET			"telnet"
#define SERVICE_NAME_SSH			"ssh"
#define SERVICE_NAME_HTTP_HTTPS		"Web"
#define SERVICE_NAME_FTP			"ftp"
#define SERVICE_NAME_UNKNOWN		"unknown"

/* for login privilege matrix */
#define SERVICE_TYPE_CONSOLE     0
#define SERVICE_TYPE_TELNET      1
#define SERVICE_TYPE_SSH         2
#define SERVICE_TYPE_HTTP_HTTPS  3
#define SERVICE_TYPE_FTP         4
#define SERVICE_TYPE_UNKNOWN     5

#define UAM_ADDRESS_NOTIFY			"/dev/user-notify"
#define UAM_ADDRESS_REQUEST			"/dev/user-request"
#define UAM_ADDRESS_ALIVE			990

#define UAM_PID_FILE				"/var/run/uamd.pid"

#define UAM_MAX_SOCKET		128

struct uam_socket
{
	struct list_head list;

#define UAM_SOCKTYPE_NOTIFY		1
#define UAM_SOCKTYPE_REQUEST	2
	char type;
	int fd;
};

/* support user locking */
#define USER_LOCK_IPC_KEY	0x11111111

#define DEFAULT_ATTEMPT_COUNT	5
#define DEFAULT_LOCKOUT_PERIOD	30
#define MAX_LOCKOUT_RECORD	1024
#define MAX_ATTEMPT_RECORD	1024

struct lockout_record {
	uint32_t ip;
	unsigned long time;
	char username[UAM_USERNAME_LEN];
	char inuse;
};

struct attempt_record {
	uint32_t ip;
	unsigned long time;
	unsigned short count;
	char inuse;
};

struct user_lock {
	char enable;
	char attempt_count;		/* per minute */
	char lockout_period;	/* in minute */
	struct lockout_record lockout_rec[MAX_LOCKOUT_RECORD];
	struct attempt_record attempt_rec[MAX_ATTEMPT_RECORD];
};

/* user login uniqueness enforcer */
#define USER_CONFIG_IPC_KEY	0x11111112

#define DEFAULT_MAX_ADMIN_LOGON_COUNT		1
#define DEFAULT_MAX_ACCESS_LOGON_COUNT		1

#define DEFAULT_MAX_IDLE_MINUTE				3
struct user_config {
	char enforce_admin_logon_count:1,
		 enforce_access_logon_count:1;
	unsigned int max_admin_logon_count;
	unsigned int max_access_logon_count;

	/* idle timeout detection for users and guests */
	char enable_idle_detection;
	unsigned int max_idle_minute;

	/* allow user update lease time automatically */
	char enable_auto_lease_update;
};

/* for pam uam failed code */
enum __pam_uam_errno {
	PAM_UAM_SUCCESS = 0,
	PAM_UAM_ERR_GET_AUTHINFO,
	PAM_UAM_ERR_ADDRESS_LOCKOUT,
	PAM_UAM_ERR_RETRIEVE_USER_PROFILE,
	PAM_UAM_ERR_VERIFY_USER,
	PAM_UAM_ERR_VALIDATE_USER,
	PAM_UAM_ERR_NOTIFY_LOGIN,
	PAM_UAM_ERR_MAX,
};

/* remove this before release */
#undef UAM_TESTING

#endif

