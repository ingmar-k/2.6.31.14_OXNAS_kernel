#ifndef __EEPROG_H__
#define __EEPROG_H__
struct ee_map_struct
{
	int address;
	int offset;
	int len;
};

struct ee_map_struct ee_map[] = {
	{ .address = 0x54, .offset = 0x0, .len = 256 } //MYZYXEL_COM section
};

enum { MYZYXEL_COM };

int get_eeprom_info(int section, void* ptr);
int set_eeprom_info(int section, void* ptr);
#endif
