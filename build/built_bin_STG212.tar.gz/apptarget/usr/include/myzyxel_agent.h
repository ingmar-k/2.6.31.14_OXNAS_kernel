#ifndef MYZYXEL_DOT_COM_H
#define MYZYXEL_DOT_COM_H

#include <syslog.h>
#include <sys/types.h>
#include <sys/sem.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include "zylog.h"

#define IDP_SERVICE     0x01
#define AS_SERVICE      0x02
#define AV_SERVICE      0x04
#define CF_SERVICE      0x05

#define EXTRACT_IDP_FAIL	-2
#define STORE_FILE_FAIL		-3
#define RESOLVE_FQDN_FAIL	-4
#define VERIFY_CERT_FAIL	-5
#define INTERNAL_SERVER_ERROR	-6
#define CONNECTION_TIMEOUT	-7

#define TRIAL_SERV	1
#define STAND_SERV	2
                                
#define MYZYXEL_ERR_EXIT_LOG(ret, msg) \
	if(ret<0) { zylog(ZYLOG_SRC_MYZYXEL_DOT_COM,ZYLOG_PRI_ERR,ZYLOG_FAC_MYZYXEL_DOT_COM, \
		0,0,0,0,"MyZyXEL.com", "%s failed",msg); \
	            return (-1); }
                                
#define MYZYXEL_ERR_NOEXIT_LOG(arg...) \
	zylog(ZYLOG_SRC_MYZYXEL_DOT_COM, ZYLOG_PRI_ERR, ZYLOG_FAC_MYZYXEL_DOT_COM, \
                                0,0,0,0,"MyZyXEL.com", ##arg)
                                
#define MYZYXEL_NOTICE_LOG(arg...) \
	zylog(ZYLOG_SRC_MYZYXEL_DOT_COM,  ZYLOG_PRI_NOTICE, ZYLOG_FAC_MYZYXEL_DOT_COM, \
                                0,0,0,0,"MyZyXEL.com", ##arg) 
#define MYZYXEL_INFO_LOG(arg...) \
	zylog(ZYLOG_SRC_MYZYXEL_DOT_COM,  ZYLOG_PRI_INFO, ZYLOG_FAC_MYZYXEL_DOT_COM, \
                                0,0,0,0,"MyZyXEL.com", ##arg)                                                                
                                
                                
#ifdef MYZYXEL_ENABLE_DEBUG                                          	
	#define MYZYXEL_DEBUG_LOG(arg...) \
		zylog(ZYLOG_SRC_MYZYXEL_DOT_COM, ZYLOG_PRI_DEBUG, ZYLOG_FAC_MYZYXEL_DOT_COM, \
			0,0,0,0,"MyZyXEL.com", ##arg)
#else
	#define MYZYXEL_DEBUG_LOG
#endif			
	
             
#define	MAX_AK_LEN	49
#define MAX_STR_LEN	64
#define MAX_SN_LEN	32
#define MAX_AC_LEN	128
#define MAX_MAIL_LEN	128
#define	MAX_SKU_LEN	256
#define MAX_LK_LEN	25
#define MAX_URL_LEN 	512
#define MAX_VERSION_LEN		128
#define	MAX_TOKEN_LEN		96000
#define	MAX_FILE_NAME		128
#define MAX_ERROR_MSG_LEN	256
#define BUFSIZE	1024
#define SOCKET_BUFFER	4096

#define MYZYXEL_INFO_CONF_TMP	"/etc/myzyxel_info_tmp.conf"
#define MYZYXEL_INFO_CONF	"/etc/myzyxel_info.conf"

#define ROOT_REG_PATH		"/register/registration"
#define ROOT_UPDATE_PATH	"/updserver/update"

#define DEVICE_TYPE 	"NGN"
#define SHMKEY ((key_t) 33778)
#define PERMS 0666
#define AUTO_CHECK_SEC 86400	
//#define AUTO_CHECK_SEC 10	

#define	ERR_CODE_1001	101
#define ERR_CODE_1001_MSG	"Invalid Username. Username cannot be found in myZyXEL.com"
#define ERR_CODE_1002	102
#define	ERR_CODE_1002_MSG	"Username Duplicate. A username has been registered by an existing user"
#define ERR_CODE_1003	103
#define	ERR_CODE_1003_MSG	"Invalid Password"
#define ERR_CODE_1004	104
#define	ERR_CODE_1004_MSG	"Invalid Serial Number/Authentication Code"
#define	ERR_CODE_1005	105
#define	ERR_CODE_1005_MSG	"The device has been registered on myZyXEL.com"
#define	ERR_CODE_1006	106
#define	ERR_CODE_1006_MSG	"Can not create account on myZyXEL.com"
#define	ERR_CODE_1007	107
#define	ERR_CODE_1007_MSG	"Can not register product on myZyXEL.com"

#define	ERR_CODE_8001	108
#define	ERR_CODE_8001_MSG	"Invalid MAC address"
#define	ERR_CODE_8002	109
#define ERR_CODE_8002_MSG	"Invalid License Key. Key length is not correct"
#define	ERR_CODE_8003	110
#define	ERR_CODE_8003_MSG	"The device has not been registered yet"
#define	ERR_CODE_8004	111
#define	ERR_CODE_8004_MSG	"Invalid License Key. This device does not support this service"
#define ERR_CODE_8005	112
#define	ERR_CODE_8005_MSG	"No match found for this license key"
#define	ERR_CODE_8006	113
#define	ERR_CODE_8006_MSG	"Incorrect iCard type for this model"
#define	ERR_CODE_8007	114
#define	ERR_CODE_8007_MSG	"Register on third party registration server faild"
#define	ERR_CODE_8008	115
#define	ERR_CODE_8008_MSG	"Register Content Filter failed"
#define	ERR_CODE_8009	116
#define	ERR_CODE_8009_MSG	"Can not activate service on myZyXEL.com"
#define	ERR_CODE_8010	117
#define	ERR_CODE_8010_MSG	"Can not synchronize service status from myZyXEL.com"

#define	ERR_CODE_8011	126
#define	ERR_CODE_8011_MSG	"Invalid License Key,license key has been used."

#define	ERR_CODE_8012	118
#define	ERR_CODE_8012_MSG	"Can not upgrade Content Filter"

#define	ERR_CODE_9001	119
#define	ERR_CODE_9001_MSG	"Invalid or not support model"
#define	ERR_CODE_9002	120
#define	ERR_CODE_9002_MSG	"Invalid or not support service"
#define	ERR_CODE_9003	121
#define	ERR_CODE_9003_MSG	"Signature update service is not activated on device"
#define	ERR_CODE_9004	122
#define	ERR_CODE_9004_MSG	"Invalid or not supported engine version"
#define	ERR_CODE_9005	123
#define	ERR_CODE_9005_MSG	"Invalid or not supported signature version"
#define	ERR_CODE_9006	124
#define ERR_CODE_9006_MSG	"Device has latest signature file; no need to update"
#define ERR_CODE_9999	125
#define	ERR_CODE_9999_MSG	"System internal error"

typedef struct myZyxelContentFilterData_s {
	int	expireDayRemain;	
	int 	service_type;	//1:trial, 2:standard
	int 	active;		//1:active, 0:not active
	int	report;		//1:has report, 0:not register report	
}myZyxelContentFilterData_t;

typedef struct myZyxelServiceData_s {
	int	expireDayRemain;	
	int 	service_type;	//1:trial, 2:standard
	int 	active;		//1:active, 0:not active	
}myZyxelServiceData_t;


typedef struct myZyxelData_s {
	char	username[MAX_STR_LEN];
	char	password[MAX_STR_LEN];
	int 	reg_status;	//0:device not registered. 1:device registered
	int	selfCheckHr;
	myZyxelContentFilterData_t	myZyxelCfData;
	myZyxelServiceData_t	myZyxelIDPData;	
	myZyxelServiceData_t	myZyxelAntiSpamData;
	myZyxelServiceData_t	myZyxelAntiVirusData;
	int	flag;	//expiration check fail flag. 1: check fail
}myZyxelData_t;

#define SHM_PATH	"/usr/sbin/reg_agent"
#define SEM_PATH_PROGRESS	"/usr/sbin/check_agent"
#define SEM_PATH	"/usr/sbin/update_agent"
#define SEM_EEPROM	"/usr/lib/libeeprog.so"
#define IDP_PROGRESS_FILE	"/tmp/idp_progress"
#define AS_PROGRESS_FILE	"/tmp/as_progress"

#define PROC_MRD 	"/proc/MRD"

/* for share memory */
struct shared_use_st {	
	int cf_active;	
	int cf_report;
	int immed_flag;	//represent whether send daily-check message
	char	username[MAX_STR_LEN];
	char	password[MAX_STR_LEN];
	int 	reg_status;	//0:device not registered. 1:device registered
	int	flag;	//expiration check fail flag. 1: check fail
	int	selfCheckHr;	
	int	idp_day;	
	int 	idp_type;	//1:trial, 2:standard
	int 	idp_reg_status;	//0:unlicensed, 1:licensed, 2 expired
	int	as_day;	
	int 	as_type;	//1:trial, 2:standard
	int 	as_reg_status;	//0:unlicensed, 1:licensed, 2 expired
	int	av_day;	
	int 	av_type;	//1:trial, 2:standard
	int 	av_reg_status;	//0:unlicensed, 1:licensed, 2 expired
	int	cf_day;	
	int 	cf_type;	//1:trial, 2:standard
	int 	cf_reg_status;	//0:unlicensed, 1:licensed, 2 expired
	int	read_flag;
};

/* structures */
struct agent_buffer {	
	int 	shmid;
	int 	semid;
	void    *addr;	
};

typedef struct msgbuf {
	long    mtype;
	char    mtext[6];
}message_buf;

/*
typedef struct{
        int known;
        struct in_addr addr;
}known_server_ip_t;
*/

#define MAX_DNS_QUERY_ATTEMPT 2

#define REG_SERVER_IP_FILE  "/var/tmp/reg_server_ip"
#define UPDATE_SERVER_IP_FILE "/var/tmp/update_server_ip"
#define IP_PATHNAME "/var/tmp/"

#endif /* MYZYXEL_DOT_COM_H */
	

