#ifndef AGENT_UTIL_H
#define AGENT_UTIL_H

#include <netinet/in.h>
#include <openssl/ssl.h>
#include <openssl/rsa.h>
#include <openssl/crypto.h>
#include <openssl/x509.h>
#include <openssl/pem.h>
#include <openssl/err.h>
#include <netinet/in.h>

#include "myzyxel_agent.h"

#define CONSOLE(format, args...)           fprintf(stdout, format, ##args)

#define CERT_FILE "/etc/ssl/certs/trusted_certificates.pem"

/* SSL/TLS version */
#define AGENT_SSLv2                     1
#define AGENT_SSLv3                     2
#define AGENT_SSLv23                    3
#define AGENT_TLSv1                     4
#define AGENT_DEFAULT_SSLVERSION        AGENT_SSLv3
#define AGENT_IPv4_LEN                  256 /* used to hold IPv4 address or FQDN */
#define AGENT_HTTPS_PORT             443
#define AGENT_REGISTER_RETRY         60
#define AGENT_CONN_TIMEOUT           60
#define MYZYXEL_EE_LEN		256
/* Receiver buffer size */
#define AGENT_RCV_BUFSIZE1               1024
#define AGENT_RCV_BUFSIZE               655350
#define MAX_CONNECTION_BASE	100

#define DIS_SER_FILE	"/var/dis_service"
/* 
 * Maxium chunk size in HTTP chunk transfer mode, 
 * or maxium content length in normal mode, never try to foo me 
 */
//#define AGENT_MAX_DATASIZE		2048
#define AGENT_MAX_DATASIZE		  6553500
						
/* TODO: 3DES secret key length */
#define DES_KEY_LEN                    	128

#define TRIAL	1
#define STANDARD	2

#define UNLICENSED	0
#define LICENSED	1
#define	EXPIRED		2

/* for API */
typedef struct myzyxel_service_s {	
	int	idp_day;	
	int 	idp_serv_type;	//1:trial, 2:standard
	int 	idp_reg_status;	//0:unlicensed, 1:licensed, 2 expired	
	
	int	as_day;	
	int 	as_serv_type;	//1:trial, 2:standard
	int 	as_reg_status;	//0:unlicensed, 1:licensed, 2 expired	
	
	int	av_day;	
	int 	av_serv_type;	//1:trial, 2:standard	
	int 	av_reg_status;	//0:unlicensed, 1:licensed, 2 expired	
	
	int	cf_day;	
	int 	cf_serv_type;	//1:trial, 2:standard	
	int 	cf_reg_status;	//0:unlicensed, 1:licensed, 2 expired	
} myzyxel_service_t;

typedef struct SEND_BUFFER_struct {
	size_t 	size;
	size_t 	used;
	char 	*buf;	
} SEND_BUFFER;


typedef struct CONNDATA_struct {
	int  			ssl_ver;	// SSL version
	int			sock;
	struct sockaddr_in	server;		// Vantage server socket address
	struct sockaddr_in	local;		// Local socket addrress
	int			retry;		// Retry interval when failed
        SSL             	*ssl;		// SSL tunnel
        SSL_CTX         	*ctx; 		// SSl context
	SEND_BUFFER		send_buf;	// Buffer for sending	
	struct myZyxelData_t	*myzyxel;	//myZyXEL_dot_com data
	char			server_ip[AGENT_IPv4_LEN];	//myZyxel.com Server's IP
	
	/* For receive Vantage server reply */
	int			parse_header;	// Parse HTTP header or not
	SEND_BUFFER		rcv_buf;	// server reply buffer
	int			content_len;	// if not 'chunked'
	short			chunksize;	// if chunk read, chunk size
	char			chunk;		// Chunk read?
	char			next_do_what;	// What to do next?
#define AGENT_READ_SKIP_CRLF		0
#define AGENT_READ_GET_CHUNKSIZE	1
#define AGENT_READ_RCV_DATA		2
	char			*str;		// Pointer to take action from
	int			nkeep;		// Number of bytes in keeper
	char			keeper[AGENT_RCV_BUFSIZE+1];

} CONNDATA;





/* exported variable(s) */
extern int rcv_bufsize;
extern char *key_file;
extern char key[DES_KEY_LEN+1];

/* util.c exported API(s) */
extern int getkey(void);
extern int agent_connect(CONNDATA *conn);
extern int agent_read(CONNDATA *conn);
extern int send_msg(CONNDATA *conn);

inline char *next_line(const char *line);
extern int build_buf(SEND_BUFFER *in, const char *fmt, ...);
extern int add_buffer(SEND_BUFFER *in, const void *p, size_t size);
extern SEND_BUFFER *add_buffer_bin(SEND_BUFFER *in, char *p, size_t size);
extern void free_conn(CONNDATA *conn);

extern int purge_tag(char *msg_buf, char *workbuf);
extern void parse_body(char *start, char *end, char *workbuf);
extern int file_copy ( char *src, char *dest );
extern int get_myzyxel_data_info(myZyxelData_t *myzyxel, struct agent_buffer *buffer);
extern void parse_sku_section(char *part, char *service, char *day);
extern void parse_sku(myZyxelData_t *myzyxel, char *service, int remainDay);
extern int save_myzyxel_sku( myZyxelData_t *myzyxel, char *sku );
extern void update_myzyxel_sku( myZyxelData_t *myzyxel );
extern int write_myzyxel_2_file( myZyxelData_t *myzyxel, struct agent_buffer *buffer);
extern int check_active(int day);
extern int build_myzyxel_buf(SEND_BUFFER *myzyxel_buf, myZyxelData_t *myzyxel);
extern myZyxelData_t * myzyxel_new();
extern int get_myZyxel_server(char *server_ip);
extern void exec_agent(char *argv[], int wait );

extern int check_av_expire(myZyxelData_t *myzyxel);
extern int check_as_expire(myZyxelData_t *myzyxel);
extern int check_idp_expire(myZyxelData_t *myzyxel);
extern int check_cf_expire(myZyxelData_t *myzyxel);
extern void set_idp_map(int flag);
//extern int get_error_code_zysh(int error);
extern int get_error_code_zysh(char *error);

extern int get_reg_status(struct agent_buffer *buffer);
extern int get_immed_flag(struct agent_buffer *buffer);
extern int read_myzyxel_from_ee(void *addr);
extern int write_myzyxel_2_ee(char *buf);
extern int get_ret_exec(char **command);
extern void agent_connect_close(CONNDATA *conn);
extern int get_mac(char *ac);
extern int get_content_length(char *buf);
extern int agent_read_bin(CONNDATA *conn);
/*
extern int agent_read_bin_as(CONNDATA *conn);
extern int agent_read_bin_idp(CONNDATA *conn);
*/
extern int get_update_server(CONNDATA *conn);
extern int set_immed_flag(struct agent_buffer *buffer, int value);

extern int update_server_ip(char * filename, struct in_addr addr);
extern int fetch_server_ip(char * filename,struct in_addr * serv_addr);
extern int agent_init(CONNDATA *conn);

/* share memory */
struct agent_buffer * init_agent_shm(void) ;
extern int attach_agent_shm(struct agent_buffer *buffer);
extern int detach_agent_shm(struct agent_buffer *buffer);

extern int notify_service(myZyxelData_t *myzyxel, struct agent_buffer *buffer);

/* semaphore */
int get_semaphore_agent(void);
int semaphore_p_agent(int semid);
int semaphore_v_agent(int semid);

extern int clear_shm(struct agent_buffer *buffer);
int clear_eeprom(void);
void disable_service(int service);

#endif /* AGENT_UTIL_H */ 

