/* $Id: libfirmware.h,v 1.1.1.1 2005/11/17 07:07:42 herenlin Exp $ */

/*
  $Log: libfirmware.h,v $
  Revision 1.1.1.1  2005/11/17 07:07:42  herenlin
  libfirmware - the library for ZLD firmware image related functions

*/

#ifndef _LIBFIRMWARE_H_
#define _LIBFIRMWARE_H_

#define ZLD_CURRENT_INFO_LEN 512
#define COMPATIBLE_PRODUCT_MODEL_NUM 5
#define COMPATIBLE_PRODUCT_MODEL_LEN 5

typedef struct zld_current_info_t
{
	unsigned char compatible_product_model[COMPATIBLE_PRODUCT_MODEL_NUM][COMPATIBLE_PRODUCT_MODEL_LEN];
}zld_current_info;

int verify_rommrd_product_model(void);
int get_zld_current_info(char *zld_current_file , zld_current_info *zu_info );
unsigned char is_product_model_compatible(unsigned char *ROMMRD_product_model,zld_current_info *zu_info);

#endif
