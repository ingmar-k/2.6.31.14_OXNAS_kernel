#define NONE	0
#define TRIAL	1
#define STANDARD	2

#define UNLICENSED	0
#define LICENSED	1
#define	EXPIRED		2
#define MAX_PROGRESS_LEN	512

#define MAX_STR_LEN	64

/* for API */
typedef struct myzyxel_service_s {		
	int	idp_day;	
	int 	idp_serv_type;	//1:trial, 2:standard
	int 	idp_reg_status;	//0:unlicensed, 1:licensed, 2 expired	
	
	int	as_day;	
	int 	as_serv_type;	//1:trial, 2:standard
	int 	as_reg_status;	//0:unlicensed, 1:licensed, 2 expired	
	
	int	av_day;	
	int 	av_serv_type;	//1:trial, 2:standard	
	int 	av_reg_status;	//0:unlicensed, 1:licensed, 2 expired	
	
	int	cf_day;	
	int 	cf_serv_type;	//1:trial, 2:standard	
	int 	cf_reg_status;	//0:unlicensed, 1:licensed, 2 expired	
} myzyxel_service_t;



/* for get service lite */
typedef struct myzyxel_service_lite_s {	
	int cf_active;	
	int cf_report;	
	int immed_flag;	//represent whether send daily-check message
	char	username[MAX_STR_LEN];
	char	password[MAX_STR_LEN];
	int 	reg_status;	//0:device not registered. 1:device registered
	int	flag;	//expiration check fail flag. 1: check fail
	int	selfCheckHr;	
	
	int	idp_day;	
	int 	idp_type;	//1:trial, 2:standard
	int 	idp_reg_status;	//0:unlicensed, 1:licensed, 2 expired
	
	int	as_day;	
	int 	as_type;	//1:trial, 2:standard
	int 	as_reg_status;	//0:unlicensed, 1:licensed, 2 expired
	
	int	av_day;	
	int 	av_type;	//1:trial, 2:standard
	int 	av_reg_status;	//0:unlicensed, 1:licensed, 2 expired
	
	int	cf_day;	
	int 	cf_type;	//1:trial, 2:standard	
	int 	cf_reg_status;	//0:unlicensed, 1:licensed, 2 expired
	
	int	read_flag;
}myzyxel_service_lite_t;


/* structures */
struct myzyxel_buffer {	
	int 	shmid;
	int 	semid;
	void    *addr;	
};

/*export function */
myzyxel_service_t * get_myzyxel_service_status(void);
struct myzyxel_buffer * init_myzyxel_shm(void);
int attach_myzyxel_shm(struct myzyxel_buffer *buffer);
int detach_myzyxel_shm(struct myzyxel_buffer *buffer);
int get_myzyxel_service_status_lite(struct myzyxel_buffer *buffer, myzyxel_service_lite_t *service_p);
int get_download_progress(int service, char *data);
int set_download_progress(char *buf);

