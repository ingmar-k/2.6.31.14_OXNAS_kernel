/* $Id: libmtd.h,v 1.2 2005/12/02 09:37:08 herenlin Exp $ */

/*
  $Log: libmtd.h,v $
  Revision 1.2  2005/12/02 09:37:08  herenlin
  Add ifdef on TRUE and FALSE

  Revision 1.1.1.1  2005/11/17 07:06:47  herenlin
  libmtd - the library for mtd related functions

*/

#ifndef _LIBMTD_H_
#define _LIBMTD_H_

#include "MRD.h"

#define DEV_MTD_START 0x75
#define DEV_MTD_COUNT 1
#define DEV_MTD_UNLOCK 0

#ifndef TRUE
#define TRUE	 (1==1)
#endif

#ifndef FALSE
#define FALSE 	 (!TRUE)
#endif

/* borrowed from linux/kdev_t.h */
#ifndef MAJOR
#define MAJOR(dev)      ((dev)>>8)
#endif
#ifndef MINOR
#define MINOR(dev)      ((dev) & 0xff)
#endif
#ifndef MKDEV
#define MKDEV(ma,mi)    ((ma)<<8 | (mi))
#endif

int found_bios_dev_name(char *bios_dev_name,int *bios_dev_minor);
int cp_rom2mrd(MRD *mrd,char *dev_mtd);
int cp_rom2proc_mrd(void);
int save_mrd2rom(MRD *mrd,char *dev_mtd);

#endif
