#ifndef LINUX_ZYXEL_H
#define LINUX_ZYXEL_H

#define DEV_SA_MAJOR_NUMBER	253

#define SA_MONITOR_DISCONNECT	0
#define SA_MONITOR_SHOW_ALL	1
#define DIAL_TUNNEL		2
#define SA_MONITOR_DISCONNECT_BY_TUNNEL_NAME 3
#define TUNNEL_SA_STATUS	4
#define SA_MONITOR_DISCONNECT_BY_INTERFACE 5


#define ENCAP_TUNNEL		0
#define ENCAP_TRANSPORT		1

#define ALG_NULL_MD5		0
#define ALG_NULL_SHA1		1
#define ALG_DES_MD5		2
#define ALG_DES_SHA1		3
#define ALG_3DES_MD5		4
#define ALG_3DES_SHA1		5
#define ALG_AES_MD5		6
#define ALG_AES_SHA1		7

#define NETBIOS_BROADCAST	0
#define NO_NETBIOS_BROADCAST	1

typedef struct sa_info {
	char name[32];
	int encap;
	int alg;
	unsigned int uptime;
	unsigned int timeout;
	char policy[64];
	unsigned char nbb;
	unsigned int spi;
}sa_info_t;

typedef struct sa_monitor_buff {
	unsigned int size;
	struct sa_info info[1000];
}sa_monitor_buff_t;

#endif
