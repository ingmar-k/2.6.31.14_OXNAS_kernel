typedef int port_t;

/* the port grouping is represented in binary format */

#ifndef MAX_PORTS
#define MAX_PORTS	8
#endif

#define NOTIFY_SYSTEM	"/usr/sbin/notify_system"
//----------by saxon-------------
#define DHCPCD_BIN	"/sbin/dhcpcd"
#define RM_BIN	"/bin/rm"
//-------------------------------
//----------by roger-------------
#define DHCP_CHG	"/sbin/dhcp_chg"
//-------------------------------
#define FROM_KERNEL 		1
#define FROM_PORT_GROUP_CHG	2

#ifndef MIN_PORTS_IN_GROUP
#define MIN_PORTS_IN_GROUP	1
#endif

#if MAX_PORTS < MIN_PORTS_IN_GROUP
#error MAX_PORTS must >= MIN_PORTS_IN_GROUP
#endif

#if MAX_PORTS % MIN_PORTS_IN_GROUP != 0
#define MAX_GROUPS	((MAX_PORTS / MIN_PORTS_IN_GROUP) + 1)
#else
#define MAX_GROUPS	(MAX_PORTS / MIN_PORTS_IN_GROUP)
#endif

#if MAX_PORTS % 8 != 0
#define BITMAP_COUNT	(MAX_PORTS / 8 + 1)
#else
#define BITMAP_COUNT	(MAX_PORTS / 8)
#endif

typedef struct {
	unsigned char member_bitmap[BITMAP_COUNT];
	unsigned char link_status[BITMAP_COUNT];
} port_group_t;

#define BITMAP_SET_PORT(bitmap, port)	(bitmap[port / 8] |= (0x80 >> (port % 8)))
#define BITMAP_ISSET_PORT(bitmap, port)	((bitmap[port / 8] & (0x80 >> (port % 8))) != 0)
#define BITMAP_UNSET_PORT(bitmap, port)	(bitmap[port / 8] &= ~(0x80 >> (port % 8)))

typedef enum {
	PORT_CONFIG = 0,
	LINK_CHANGE
} link_updown_cmd;

typedef struct {
	unsigned int port_no;
	unsigned int group_no;
} port_belong_t ;

typedef struct {
	int command;
	union {
		unsigned char link_status[BITMAP_COUNT];	/* for LINK_CHANGE */
		port_belong_t port_config;			/* for PORT_CONFIG */
	} payload;
} link_updown_msg;

#define LINK_UPDOWN_NETLINK	29
#define LINK_UPDOWN_MCAST_GROUP	0xFFFF
#define LINK_UPDOWN_SOCKET	"/tmp/link-updown-socket"

#ifndef __KERNEL__
/* used for user-space only */

#define LINK_IS_DOWN	0
#define LINK_IS_UP	1

#endif
