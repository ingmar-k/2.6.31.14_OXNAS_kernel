#ifndef _USER_PROFILE_H_
#define _USER_PROFILE_H_

#define IN_USER_NAME_LEN 	32
#define TYPE_LEN	12
#define IN_USER_PASSWORD_LEN 	64
#define DESC_LEN 1024
#define MAX_USER_NUM	1024

#define SHMKEY_PAM_PATH	"/lib/security/pam_auth_admin.so"
#define SEM_PATH	"/lib/security/pam_unix.so"
#define PERMS_PAM 0666

#define GROUP_BACKUP_FILE	"/tmp/template_group.xml"
#define USER_BAKCUP_FILE	"/tmp/template_user.xml"

#define ADMIN_TYPE	0
#define USER_TYPE	1
#define GUEST_TYPE	2
#define	EXT_TYPE	3
#define LIMIT_TYPE	4
#define NONE_TYPE	-1

#define LDAP_TIMEOUT	5
#define MAX_AUTH_ENTRY	50
#define MAX_USER_ENTRY 50
	
#define ADMIN_PRIV	120
#define LIMIT_PRIV	100
#define USER_PRIV	80
#define	EXT_PRIV	80
#define GUEST_PRIV	50

#define IN_USER_DEFAULT_ADMIN	1
#define IN_USER_DEFAULT_ACCESS	1
#define IN_USER_DEFAULT_NO_ADMIN	0
#define IN_USER_DEFAULT_NO_ACCESS	0
#ifdef ENABLE_SAMBA
#define IN_USER_DEFAULT_LEASE_TIME	10
#define IN_USER_DEFAULT_REAUTH_TIME	180
#endif /* ENABLE_SAMBA */
	
/* support external database users */
#define DEFAULT_LDAP_USERS      "ldap-users"
#define DEFAULT_RADIUS_USERS    "radius-users"

typedef struct user_profile_s {		
	char username[IN_USER_NAME_LEN];
	char virtual_username[IN_USER_NAME_LEN];
#ifdef ENABLE_SAMBA
	char password[IN_USER_PASSWORD_LEN];
#endif /* ENABLE_SAMBA */
	char desc[DESC_LEN];
	int type;
	int access;
	int visibility;	 
	int lease_time;
	int reauth_time;
	int remote_admin;
	int remote_access;
	int refCnt;
} user_profile_t;

typedef struct user_group_s
{
	char name[IN_USER_NAME_LEN];
	char desc[DESC_LEN];	
	user_profile_t user[MAX_USER_NUM];
	int user_num;	
} user_group_t;


/* for share memory with user profile */
typedef struct shared_user_s {	
	int used;
	char username[IN_USER_NAME_LEN];	
	char password[IN_USER_PASSWORD_LEN];
	int type;
	int access;
	int visibility;	 
	int lease_time;
	int reauth_time;
	int remote_admin;
	int remote_access;	
} shared_user_t;

typedef struct user_auth_list_s {	
	int used;
	char username[IN_USER_NAME_LEN];	
	int module;	//1:pam_unix, 2:pam_radius_auth, others:pam_ldap	
} user_auth_list_t;

struct shared_mem_s {	
	user_auth_list_t auth_list[MAX_AUTH_ENTRY];
	shared_user_t user_p[MAX_USER_ENTRY];
	
};

/* export function */
user_profile_t * get_user_profile(char *username );
int check_user_in_group(char *group_name, char *user_name);
int release_auth_list(char *username);
user_group_t * retrieve_user_group(char *group_name);
int verify_user_group(char *group_name);
#endif

/* vi:set sw=4 ts=4: */
