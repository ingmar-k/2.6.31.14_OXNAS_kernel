/* $Id: */

/*
 * $Log:
 */

#ifndef _IFNAME_CHANGE_H_
#define _IFNAME_CHANGE_H_
#include "ifacename_change.h"
#define FILENAMESIZE 128
#define STRZISE 128
#define ADDR_LEN 16

int eth_to_user_define (char *iface, char *ud_iface);
int user_define_to_eth (char *ud_iface, char *iface);

int wlan_to_user_define (char *iface, char *ud_iface);
int user_define_to_wlan (char *ud_iface, char *iface);

int ppp_trigger_query(char* ip_addr);
int query_interface_link_status(char *iface);
int check_ppp_connected(char *ppp_dev);
enum {
	IFACE_PORT_LINK_DOWN,
	IFACE_PORT_LINK_UP,
	INTERFACE_DOWN_OR_NOT_EXIST
};
#endif
