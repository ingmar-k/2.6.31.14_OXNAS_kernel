/* $Id: spec.h,v 1.3 2005/11/08 11:06:13 edward Exp $ */

/*
 * $Log: spec.h,v $
 * Revision 1.3  2005/11/08 11:06:13  edward
 * test check-in
 *
 * Revision 1.2  2005/02/04 07:10:50  edward
 * replace idle timeout with lease timeout
 *
 * Revision 1.1.1.1  2004/12/23 06:28:24  edward
 * initial release
 *
 */

#ifndef _SPEC_H_
#define _SPEC_H_

#define UAM_MAX_USERS		1024

/* UAM_REAUTH_TIME in minutes */
#define UAM_REAUTH_TIME     (8*60) /* 8 hours */
/* UAM_REAUTH_TIME in minutes */
#define UAM_LEASE_TIME      (30)   /* 30 minutes */


#endif
