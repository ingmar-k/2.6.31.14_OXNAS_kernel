#!/bin/sh

HTP_MAIN="/usr/local/htp/htp_main"
HTP_TEST_ITEMS="/usr/local/htp/htp_test_items"

##############
# led test
##############
# set SATA MPP to output
$HTP_MAIN atwl0xf1010004,0x0000000 > /dev/null
# set gpio blink off
$HTP_MAIN atwl0xf1010108,0x00000000 > /dev/null
# set gpio output enable
$HTP_MAIN atwl0xf1010104,0x004D048C > /dev/null

# set all green/red led off
$HTP_MAIN atwl0xf1010100,0x820473 > /dev/null

# set all red led on
$HTP_MAIN atwl0xf1010108,0x00000063 > /dev/null
# delay for a while
$HTP_TEST_ITEMS togglebit 0xf1010100 0x00000001 10000 > /dev/null
#sleep 1

# set all green led on
$HTP_MAIN atwl0xf1010108,0x0002C010 > /dev/null
# delay for a while
$HTP_TEST_ITEMS togglebit 0xf1010100 0x00000010 10000 > /dev/null

# set gpio output enable back
$HTP_MAIN atwl0xf1010104,0x004D048F > /dev/null
# set gpio blink back
$HTP_MAIN atwl0xf1010108,0x0000C000 > /dev/null
# set STAT MPP back
$HTP_MAIN atwl0xf1010004,0x55550000 > /dev/null 
