#!/bin/sh

MAGIC_NUM=`cat /proc/mcu | grep MagicNum | cut -d: -f2`
counter=0
while [ $counter -lt 3 ]; do
	if [ "${MAGIC_NUM}" != "85" ]; then
		#echo "failed"
#		exit 1;
		sleep 1
		counter=$(($counter+1))
		MAGIC_NUM=`cat /proc/mcu | grep MagicNum | cut -d: -f2`
	else
		#echo "ok"
		exit 0;
	fi
done

exit 1;
