#!/bin/sh
cat /proc/pci | grep $1 > /dev/null
if [ $? != 0 ]; then
	#echo "failed"
	exit 1
else
	#echo "ok"
	exit 0
fi
