#!/bin/sh

###  Use sg_map see the device mapping relation  ###
locate=`sg_map -x -i | grep $1`

if [ "$locate" != "" ]; then
    /bin/echo $locate | grep " 0 0 0 0 0" > /dev/null
    if [ $? -eq 0 ]; then
    	printf "SATA0 "
    fi
    
    /bin/echo $locate | grep " 1 0 0 0 0" > /dev/null
    if [ $? -eq 0 ]; then 
    	printf "SATA1 "
    fi


		###  For usb, we must see the usb link in /sys/block/sdn  ###

   

      if [ $1 == "/dev/sda" ]; then
        ls -al /sys/block/sda/ | grep usb1  > /dev/null
        if [ $? -eq 0 ]; then
                printf "USB0 "
        fi

        ls -al /sys/block/sda/ | grep usb2  > /dev/null
        if [ $? -eq 0 ]; then
                printf "USB1 "
        fi
    fi

    if [ $1 == "/dev/sdb" ]; then
            ls -al /sys/block/sdb/ | grep usb1  > /dev/null
            if [ $? -eq 0 ]; then
                printf "USB0 "
            fi

            ls -al /sys/block/sdb/ | grep usb2  > /dev/null
            if [ $? -eq 0 ]; then
                printf "USB1 "
            fi
    fi
	


			
    if [ $1 == "/dev/sdc" ]; then     
    	ls -al /sys/block/sdc/ | grep usb1  > /dev/null
    	if [ $? -eq 0 ]; then 
	    	printf "USB0 "    
    	fi
    
    	ls -al /sys/block/sdc/ | grep usb2  > /dev/null
    	if [ $? -eq 0 ]; then 
    		printf "USB1 "    
    	fi
    fi
    
    if [ $1 == "/dev/sdd" ]; then     
	    ls -al /sys/block/sdd/ | grep usb1  > /dev/null
	    if [ $? -eq 0 ]; then 
	    	printf "USB0 "    
	    fi
	    
	    ls -al /sys/block/sdd/ | grep usb2  > /dev/null
	    if [ $? -eq 0 ]; then 
	    	printf "USB1 "    
	    fi
    fi
fi


badblocks  $1 $2 $3 > /dev/null
if [ $? -ne 0 ]; then
	#echo "failed"
	exit 1
else
	#echo "ok"
	exit 0
fi
