#!/bin/sh
# $1: device such as /dev/mtdblock1 which was mounted under /etc/zyxel
# $2: mount point such as /etc/zyxel
# $3: test file under /lib directory, around 200KB

cat /proc/mounts | grep "/etc/zyxel" > /dev/null
if [ $? == 0 ] ; then
	#echo "umounting /etc/zyxel"
	umount /etc/zyxel
fi

badblocks -w -t 0x5a -t 0xa5 -t 0x00 -t 0xff $1 $2 $3 > /dev/null
if [ $? != 0 ] ; then
	#echo "failed"
	exit 1
else
	#echo "ok"
	exit 0
fi


########################################
# test with r/w mode
########################################
#cp -f /lib/$3 $2/$3

#umount $2

#mount -t jffs2 $1 $2

#cmp -s /lib/$3 $2/$3
#if [ $? != 0 ] ; then
  #echo "failed"
#  rm -f $2/$3
#	exit 1;
#fi

#rm -f $2/$3
#echo "ok"
#exit 0;
