#!/bin/sh

# touch /etc/zyxel/script/run_htp_external for HTP to execute productino test
echo "0" > /etc/zyxel/script/run_htp_external

sync;sync;sync;reboot
