#!/bin/sh

# disable POWER button interrupt first
/usr/sbin/htp_main atwl0xf1010118,0xc0000

####################################
# test factory reset pin
####################################
echo "TEST Factory Reset Pin"
/usr/sbin/htp_test_items io 0xf1010110 0x00000008 0x00000008
echo "ok!"

##################
# test copy pin
##################
echo "TEST Copy Pin"
/usr/sbin/htp_test_items io 0xf1010110 0x00000080 0x00000080
echo "ok!"

##################
# test power pin
##################
echo "TEST Power Pin"
/usr/sbin/htp_test_items io 0xf1010110 0x00400000 0x00400000
echo "ok!"

##############
# test buzzer
##############
/usr/sbin/htp_test_items togglebit 0xf1010100 0x02000000 10000

##############
# led test
##############
# set SATA MPP to output
htp_main atwl0xf1010004,0x0000000
# set gpio blink off
htp_main atwl0xf1010108,0x00000000
# set gpio output enable
htp_main atwl0xf1010104,0x004D048C

# set all red led on
htp_main atwl0xf1010108,0x00000063
# delay for a while
htp_test_items togglebit 0xf1010100 0x00000001 10000

# set all green led on
htp_main atwl0xf1010108,0x0002C010
# delay for a while
htp_test_items togglebit 0xf1010100 0x00000010 10000

# set gpio output enable back
htp_main atwl0xf1010104,0x004D048F
# set gpio blink back
htp_main atwl0xf1010108,0x0000C000
# set STAT MPP back
htp_main atwl0xf1010004,0x55550000