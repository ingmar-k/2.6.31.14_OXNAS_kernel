#!/bin/sh

PRE_VALUE=`/zyxel/htp/htp_main atrl0xf1010300`
sleep 3
CUR_VALUE=`/zyxel/htp/htp_main atrl0xf1010300`

if [ "${PRE_VALUE}" == "${CUR_VALUE}" ]; then
	#echo fail
	exit 1
else
	#echo OK
	exit 0 
fi 
