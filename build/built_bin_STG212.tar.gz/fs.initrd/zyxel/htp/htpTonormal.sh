rm -f /etc/zyxel/script/run_htp_external

