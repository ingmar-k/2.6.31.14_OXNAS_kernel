#!/bin/sh
i2cget -y $1 $2 $3 b > /dev/null
if [ $? != 0 ]; then
	#echo "failed"
	exit 1;
else
	#echo "ok"
	exit 0;
fi
