#!/bin/sh

echo "HTP Start."

#Model id
mrd_model -p

#show fw version
cat /etc/fwversion

#show checksum
mrd_corechecksum
sleep 1
mrd_zldchecksum
sleep 1
mrd_romfilechecksum
sleep 1

#show thermal sensor input
cat /sys/devices/platform/i2c-0/0-002e/temp1_input
cat /sys/devices/platform/i2c-0/0-002e/temp2_input
cat /sys/devices/platform/i2c-0/0-002e/temp3_input
##cat /sys/devices/platform/i2c-0/0-002e/fan1_input
cat /tmp/fan1_average # fan average file name should be refer to usb_key_func.sh
read a
./htp_main -f htp.lst.external
./htp_test_items mac

echo "HTP Done."
