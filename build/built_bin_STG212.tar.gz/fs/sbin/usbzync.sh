#!/bin/sh
#exit code
#1:err
#2:/tmp/stopsync.lock exist
#3:Backup Folder Does Not Exist
#13:A is dir, B is a file
#14:lock exist
#15:full
#16:copy failed
#17:move failed
#18:delete failed
#Note: cp -r will fail in FAT32, but cp -fp, mv -f will not
# cp: unable to preserve ownership of `./libwrap.so.0': Operation not permitted
# mv: unable to preserve ownership of `./dir1': Operation not permitted

bsname=${0##/*/}
echo "${bsname}:${@}" >> /tmp/michael.txt

FAILEXIT ()
{
	echo $1 > /tmp/cpbtnd_result.return
	rm -f ${btnlock}
	killall -4 do_btncpy

	if [ "${idA}" == "iPhone/iPodTouch" ]; then
		rm -rf /i-data/md0/.system/idevice_${idevice_uuid}
	fi

	exit $1
}

if [ "${1}" == "iPhone/iPodTouch" ]; then
	idA=${1}
	idevice_uuid=`/usr/local/btn/imobileController -l | awk '{print $4}' | awk -F: '{print $2}'`
	if [ "${idevice_uuid}" == "" ]; then
		echo "${bsname}:${@} iPhone/iPodTouch doesn't exist" >> /tmp/michael.txt
		zylogger -s 17 -p 3 -f 17 "[USB ${cata}] iPhone/iPodTouch doesn't exist."
		echo -e "-1\niPhone/iPodTouch doesn't exist" > /tmp/copy_sync_status.txt
		FAILEXIT 1
	fi
else
	idA=`echo ${1}|cut -d '/' -f 3`
fi
idB=`echo ${2}|cut -d '/' -f 3`

if [ "${idA}" == "" ] || [ "${idB}" == "" ]; then
	echo "${bsname}:${@} not mp" >> /tmp/michael.txt
	echo "usage:${bsname} /e-data/12345678|iPhone/iPodTouch /i-data/c0617e1d/share1 /i-data/c0617e1d/public/usbsync_backup_080527025400 sync2Vol|sync2USB|twoWay|cp2Vol|cp2USB" > /dev/console
	echo -e "-1\nUnexpected Error" > /tmp/copy_sync_status.txt
	FAILEXIT 1
fi

backupC=""
if [ $# -eq 4 ]; then
	backupC=1
	direction=${4}
else
	if [ $# -eq 3 ]; then
		backupC=""
		direction=${3}
	else
		echo "usage:${bsname} /e-data/12345678|iPhone/iPodTouch /i-data/c0617e1d/share1 /i-data/c0617e1d/public/usbsync_backup_080527025400 sync2Vol|sync2USB|twoWay|cp2Vol|cp2USB" > /dev/console
		echo -e "-1\nUnexpected Error" > /tmp/copy_sync_status.txt
		FAILEXIT 1
	fi
fi

#generate btnlock(needn't this lock file for iPhone/iPodTouch)
if [ "${idA}" == "iPhone/iPodTouch" ]; then
	if [ "${direction}" == "cp2Vol" ]; then
		cata="Copy"
	elif [ "${direction}" == "sync2Vol" ]; then
		cata="Sync"
	else
		echo "Only one way copy/sync for iPhone/iPodTouch" >> /tmp/michael.txt
		echo -e "-1\nOnly one way copy/sync for iPhone/iPodTouch" > /tmp/copy_sync_status.txt
		FAILEXIT 1
	fi
else
	if  [ "${direction}" == "cp2USB" ] || [ "${direction}" == "cp2Vol" ]; then
		btnlock="/tmp/btnd_${idA}.lock"
		cata="Copy"
	else
		btnlock="/tmp/copybtnd.lock"
		cata="Sync"
	fi
	if [ -e ${btnlock} ]; then
		echo "${bsname}:${btnlock} exists" >> /tmp/michael.txt
		# do not send duplicate signal
		echo 14 > /tmp/cpbtnd_result.return
		exit 14
	fi
	touch ${btnlock}
fi

#check if abc exist
if [ "${1}" != "iPhone/iPodTouch" ] && [ ! -d "${1}" ]; then
	echo "${bsname}:${@} not dir" >> /tmp/michael.txt
	zylogger -s 17 -p 3 -f 17 "[USB ${cata}] Target Folder Does Not Exist."
	echo -e "-1\nTarget Folder Does Not Exist" > /tmp/copy_sync_status.txt
	FAILEXIT 1
fi
if [ ! -d "${2}" ]; then
	echo "${bsname}:${@} not dir" >> /tmp/michael.txt
	zylogger -s 17 -p 3 -f 17 "[USB ${cata}] Target Folder Does Not Exist."
	echo -e "-1\nTarget Folder Does Not Exist" > /tmp/copy_sync_status.txt
	FAILEXIT 1
fi
if [ $# -eq 4 ] && [ ! -d "${3}" ]; then
	echo "${bsname}:${@} not dir" >> /tmp/michael.txt
	zylogger -s 17 -p 3 -f 17 "[USB ${cata}] Backup Folder Does Not Exist."
	echo -e "-1\nBackup Folder Does Not Exist" > /tmp/copy_sync_status.txt
	FAILEXIT 1
fi

#dir list
if [ -d /i-data/md0 ]; then
	listA="/i-data/md0/.system/${idA}_A.usbzync"
	listB="/i-data/md0/.system/${idB}_B.usbzync"
else
	listA="/tmp/${idA}_A.usbzync"
	listB="/tmp/${idB}_B.usbzync"
fi

#dump iPhone/iPodTouch
if [ "${1}" == "iPhone/iPodTouch" ]; then
	if [ -d /i-data/md0/.system ]; then
		idevice_dir=/i-data/md0/.system/idevice_${idevice_uuid}
		if [ -d ${idevice_dir} ]; then
			ps | grep "usbzync.sh" | grep -v grep

			if [ "$?" == "0" ]; then
				echo "${bsname}:${@} ${idevice_dir} already exists" >> /tmp/michael.txt
				zylogger -s 17 -p 3 -f 17 "[USB ${cata}] Fail to copy/sync media from iPhone/iPodTouch."
				# do not send duplicate signal
				echo 19 > /tmp/cpbtnd_result.return
				exit 19
			else
				rm -rf ${idevice_dir}
			fi
		fi

		echo -e "0\nStart copying/syncing data with iPhone/iPodTouch" > /tmp/copy_sync_status.txt
		mkdir -p ${idevice_dir}
		/usr/local/btn/imobileController -u ${idevice_uuid} -d ${idevice_dir} -p /tmp/copy_sync_status.txt -M 90 > /tmp/idevice.log 2>&1

		if [ ! -d ${idevice_dir}/.gtkpod/musicdump ]; then
			rm -rf ${idevice_dir}
			echo "${bsname}:${@} can't mount iPhone/iPodTouch" >> /tmp/michael.txt
			zylogger -s 17 -p 3 -f 17 "[USB ${cata}] Fail to copy/sync media from iPhone/iPodTouch."
			echo -e "-1\nFail to copy/sync media from iPhone/iPodTouch" > /tmp/copy_sync_status.txt
			FAILEXIT 1
		else
			listA=${idevice_dir}/idevice_list
			idevice_dir=${idevice_dir}/.gtkpod/musicdump
		fi
	else
		echo "${bsname}:${@} /i-data/md0/.system doesn't exist" >> /tmp/michael.txt
		zylogger -s 17 -p 3 -f 17 "[USB ${cata}] /i-data/md0/.system doesn't exist."
		echo -e "-1\nUnexpected Error" > /tmp/copy_sync_status.txt
		FAILEXIT 1
	fi
fi

start_t=`date +%s`
rm -f /tmp/cpbtnd_result.return

zylogger -s 17 -p 6 -f 17 "[USB ${cata}] Start Pre-Processing: Generating File Lists."

#find A(needn't this lock file for iPhone/iPodTouch)
if [ "${idA}" != "iPhone/iPodTouch" ] && [ -e /tmp/stopsync.lock ]; then
	echo "${bsname}:/tmp/stopsync.lock exist" >> /tmp/michael.txt
	echo -e "-1\nButton is Disabled" > /tmp/copy_sync_status.txt
	FAILEXIT 2
fi

#handle share named archive-julian$
if [ "${idA}" == "iPhone/iPodTouch" ]; then
	echo "cd \"${idevice_dir}\"; find . -type d|cut -c 2- > ${listA}" >> /tmp/michael.txt
	cd "${idevice_dir}"; find . -type d|cut -c 2- > ${listA}
else
	echo "cd \"${1}\"; find . -type d|cut -c 2- > ${listA}" >> /tmp/michael.txt
	cd "${1}"; find . -type d|cut -c 2- > ${listA}
fi

#find B(needn't this lock file for iPhone/iPodTouch)
if [ "${idA}" != "iPhone/iPodTouch" ] && [ -e /tmp/stopsync.lock ]; then
	echo "${bsname}:/tmp/stopsync.lock exist" >> /tmp/michael.txt
	echo -e "-1\nButton is Disabled" > /tmp/copy_sync_status.txt
	FAILEXIT 2
fi
echo "cd \"${2}\"; find . -type d|cut -c 2- > ${listB}" >> /tmp/michael.txt
cd "${2}"; find . -type d|cut -c 2- > ${listB}

#rm -rf for one-way sync
#if [ "${direction}" == "sync2Vol" ] || [ "${direction}" == "sync2USB" ]; then
#	usbzync_rm_rf.sh "${@}"
#	result=$?
#	if [ $result -ne 0 ]; then
#		echo -e "-1\nFailed to Delete Folder" > /tmp/copy_sync_status.txt
#		FAILEXIT $result
#	fi
#fi

#mkdir for A
if [ "${direction}" != "sync2Vol" ] && [ "${direction}" != "cp2Vol" ]; then
	#for i in `cat ${listB}`; do	#problem:path with space
	#cat ${listB} | while read i; do	#problem:var=$line
	while read d_i; do
		#needappend=`cat ${listA}|grep -E "^${d_i}$"`
		#if [ "${needappend}" == "" ]; then
		if [ ! -e "${1}${d_i}" ]; then
			echo "mkdir -p -m 777 ${1}${d_i}" > /dev/console
			mkdir -p -m 777 "${1}${d_i}"
		fi
		if [ ! -d "${1}${d_i}" ]; then
			echo "zylogger -s 17 -p 3 -f 17 [USB ${cata}] Failed at Folder ${d_i##/}: Cannot create the Folder ${d_i##/} in USB." >> /tmp/michael.txt
			zylogger -s 17 -p 3 -f 17 "[USB ${cata}] Failed at Folder ${d_i##/}: Cannot create the Folder ${d_i##/} in USB."
			echo -e "-1\nCannot create the Folder ${d_i##/} in USB" > /tmp/copy_sync_status.txt
			FAILEXIT 13
		fi
	done < ${listB}
fi

#mkdir for B
if [ "${direction}" != "sync2USB" ] && [ "${direction}" != "cp2USB" ]; then
	while read d_i; do
		if [ ! -e "${2}${d_i}" ]; then
			echo "mkdir -p -m 777 ${2}${d_i}" > /dev/console
			mkdir -p -m 777 "${2}${d_i}"
		fi
		if [ ! -d "${2}${d_i}" ]; then
			echo "zylogger -s 17 -p 3 -f 17 [USB ${cata}] Failed at Folder ${d_i##/}: Cannot create the Folder ${d_i##/} in Internal Volume." >> /tmp/michael.txt
			zylogger -s 17 -p 3 -f 17 "[USB ${cata}] Failed at Folder ${d_i##/}: Cannot create the Folder ${d_i##/} in Internal Volume."
			echo -e "-1\nCannot create the Folder ${d_i##/} in Internal Volume" > /tmp/copy_sync_status.txt
			FAILEXIT 13
		fi
	done < ${listA}
fi

#file list
if [ "${1}" != "iPhone/iPodTouch" ]; then
	rm -f /tmp/*.usbzync
	if [ -d /i-data/md0 ]; then
		rm -f /i-data/md0/.system/*.usbzync
		listA="/i-data/md0/.system/${idA}_A.usbzync"
		listB="/i-data/md0/.system/${idB}_B.usbzync"
	else
		listA="/tmp/${idA}_A.usbzync"
		listB="/tmp/${idB}_B.usbzync"
	fi
fi

#listA by A(needn't this lock for iPhone/iPodTouch)
if [ "${1}" != "iPhone/iPodTouch" ] && [ -e /tmp/stopsync.lock ]; then
	echo "${bsname}:/tmp/stopsync.lock exist" >> /tmp/michael.txt
	echo -e "-1\nButton is Disabled" > /tmp/copy_sync_status.txt
	FAILEXIT 2
fi
if [ "${direction}" == "cp2Vol" ]; then
	if [ "${1}" == "iPhone/iPodTouch" ]; then
		echo "cd  \"${idevice_dir}\"; find . -type f|cut -c 2- > ${listA}" >> /tmp/michael.txt
		cd "${idevice_dir}"; find . -type f|cut -c 2- > ${listA}
	else
		echo "cd  \"${1}\"; find . -type f|cut -c 2- > ${listA}" >> /tmp/michael.txt
		cd "${1}"; find . -type f|cut -c 2- > ${listA}
	fi
fi

#listA by B(needn't this lock for iPhone/iPodTouch)
if [ "${1}" != "iPhone/iPodTouch" ] && [ -e /tmp/stopsync.lock ]; then
	echo -e "-1\nButton is Disabled" > /tmp/copy_sync_status.txt
	FAILEXIT 2
fi

#For iPhone/iPodTouch, never enter this condition
if [ "${direction}" == "cp2USB" ]; then
	echo "cd \"${2}\"; find  -type f|cut -c 2- > ${listA}" >> /tmp/michael.txt
	cd "${2}"; find . -type f|cut -c 2- > ${listA}
fi

#A is the final result
if [ "${direction}" != "cp2Vol" ] && [ "${direction}" != "cp2USB" ]; then
	#needn't this lock for iPhone/iPodTouch
	if [ "${1}" != "iPhone/iPodTouch" ] && [ -e /tmp/stopsync.lock ]; then
		echo "${bsname}:/tmp/stopsync.lock exist" >> /tmp/michael.txt
		echo -e "-1\nButton is Disabled" > /tmp/copy_sync_status.txt
		FAILEXIT 2
	fi

	if [ "${1}" == "iPhone/iPodTouch" ]; then
		echo "cd \"${idevice_dir}\"; find . -type f|cut -c 2- > ${listA}" >> /tmp/michael.txt
		cd "${idevice_dir}"; find . -type f|cut -c 2- > ${listA}
	else
		echo "cd \"${1}\"; find . -type f|cut -c 2- > ${listA}" >> /tmp/michael.txt
		cd "${1}"; find . -type f|cut -c 2- > ${listA}
	fi

	#needn't this lock for iPhone/iPodTouch
	if [ "${1}" != "iPhone/iPodTouch" ] && [ -e /tmp/stopsync.lock ]; then
		echo "${bsname}:/tmp/stopsync.lock exist" >> /tmp/michael.txt
		echo -e "-1\nButton is Disabled" > /tmp/copy_sync_status.txt
		FAILEXIT 2
	fi

	if [ "${1}" == "iPhone/iPodTouch" ]; then
		dir_a=${idevice_dir}
	else
		dir_a=${1}
	fi

	echo "cd \"${2}\"; find . -type f|cut -c 2- > ${listB}" >> /tmp/michael.txt
	cd "${2}"; find . -type f|cut -c 2- > ${listB}
	while read i; do
		#needappend=`cat ${listA}|grep -E "^${i}$"`
		#if [ "${needappend}" == "" ]; then
		if [ ! -e "${dir_a}${i}" ]; then
			echo "${i}" >> ${listA}
		fi
	done < ${listB}
fi
cd /
zylogger -s 17 -p 5 -f 17 "[USB ${cata}] Start Copying Files."

if [ "${1}" == "iPhone/iPodTouch" ]; then
	dir_a=${idevice_dir}
else
	dir_a=${1}
fi

cpresult=0
cpresult1=0
#case_return
deno=`wc -l ${listA}|awk '{print $1}'`
nume=0
while read f_i; do
	#/share/file1
	if [ "${backupC}" == "1" ]; then
		usbzync "${dir_a}${f_i}" "${2}${f_i}" "${3}" "${f_i}" "${4}"
		case_return=$?
	else
		usbzync "${dir_a}${f_i}" "${2}${f_i}" "${f_i}" "${3}"
		case_return=$?
	fi

	let "nume = $nume + 1"
	if [ "${idA}" == "iPhone/iPodTouch" ]; then
		let "perc=90+${nume}*100/${deno}/10"
	else
		let "perc=${nume}*100/${deno}"
	fi
	if [ "${perc}" == "100" ]; then
		perc=99
	fi
	echo -e "${perc}\n${f_i}" > /tmp/copy_sync_status.txt

	#needn't this lock for iPhone/iPodTouch
	if [ "${1}" != "iPhone/iPodTouch" ] && [ -e /tmp/stopsync.lock ]; then
		echo "${bsname}:/tmp/stopsync.lock exist" >> /tmp/michael.txt
		echo -e "-1\nButton is Disabled" > /tmp/copy_sync_status.txt
		FAILEXIT 2
	fi

	case $case_return in
		1)
			#A->B
			echo "cp -fp ${dir_a}${f_i} ${2}${f_i}" > /dev/console
			zylogger -s 17 -p 6 -f 17 "[USB ${cata}] Copying ${f_i##/} from USB to Internal Volume."
			cp -fp "${dir_a}${f_i}" "${2}${f_i}"
			cpresult=$?
			chmod 777 "${2}${f_i}"
			;;
		2)
			#B->A
			echo "cp -fp ${2}${f_i} ${dir_a}${f_i}" > /dev/console
			zylogger -s 17 -p 6 -f 17 "[USB ${cata}] Copying ${f_i##/} from Internal Volume to USB."
			cp -fp "${2}${f_i}" "${dir_a}${f_i}"
			cpresult=$?
			chmod 777 "${dir_a}${f_i}"
			;;
		3)
			#C err
			echo "${bsname}:${3} not exist" >> /tmp/michael.txt
			zylogger -s 17 -p 3 -f 17 "[USB ${cata}] Backup Folder Does Not Exist."
			echo -e "-1\nBackup Folder Does Not Exist" > /tmp/copy_sync_status.txt
			FAILEXIT 3
			;;
		4)
			#B->C,A->B
			dirC="${3}${f_i}"
			echo "mkdir -p -m 777 ${dirC%/*}" > /dev/console
			mkdir -p -m 777 "${dirC%/*}"
			echo "cp -fp ${2}${f_i} ${3}${f_i}" > /dev/console
			zylogger -s 17 -p 6 -f 17 "[USB ${cata}] Copying ${f_i##/} from Internal Volume to Backup Folder."
			cp -fp "${2}${f_i}" "${3}${f_i}"
			cpresult1=$?
			chmod 777 "${3}${f_i}"

			echo "cp -fp ${dir_a}${f_i} ${2}${f_i}" > /dev/console
			zylogger -s 17 -p 6 -f 17 "[USB ${cata}] Copying ${f_i##/} from USB to Internal Volume."
			cp -fp "${dir_a}${f_i}" "${2}${f_i}"
			cpresult=$?
			chmod 777 "${2}${f_i}"
			;;
		5)
			#A->C,B->A
			dirC="${3}${f_i}"
			echo "mkdir -p -m 777 ${dirC%/*}" > /dev/console
			mkdir -p -m 777 "${dirC%/*}"
			echo "cp -fp ${dir_a}${f_i} ${3}${f_i}" > /dev/console
			zylogger -s 17 -p 6 -f 17 "[USB ${cata}] Copying ${f_i##/} from USB to Backup Folder."
			cp -fp "${dir_a}${f_i}" "${3}${f_i}"
			cpresult1=$?
			chmod 777 "${3}${f_i}"

			echo "cp -fp ${2}${f_i} ${dir_a}${f_i}" > /dev/console
			zylogger -s 17 -p 6 -f 17 "[USB ${cata}] Copying ${f_i##/} from Internal Volume to USB."
			cp -fp "${2}${f_i}" "${dir_a}${f_i}"
			cpresult=$?
			chmod 777 "${dir_a}${f_i}"
			;;
		6)
			#-300~300
			#zylogger -s 17 -p 6 -f 17 "[USB ${cata}] Skip ${f_i##/}: Time Difference is Less Than 5 Minutes."
			echo "#zylogger -s 17 -p 6 -f 17 [USB ${cata}] Skip ${f_i##/}: Time Difference is Less Than 5 Minutes." > /dev/console
			;;
		7)
			#not file
			zylogger -s 17 -p 6 -f 17 "[USB ${cata}] Skip ${f_i##/}: Not a Regular File."
			;;
		8)
			#delete A
			zylogger -s 17 -p 6 -f 17 "[USB ${cata}] Deleting ${f_i##/} from USB."
			echo "rm -f ${dir_a}${f_i}" > /dev/console
			rm -f "${dir_a}${f_i}"
			cpresult=$?
			;;
		9)
			#delete B
			zylogger -s 17 -p 6 -f 17 "[USB ${cata}] Deleting ${f_i##/} from Internal Volume."
			echo "rm -f ${2}${f_i}" > /dev/console
			rm -f "${2}${f_i}"
			cpresult=$?
			;;
		10)
			#mv A C
			dirC="${3}${f_i}"
			echo "mkdir -p -m 777 ${dirC%/*}" > /dev/console
			mkdir -p -m 777 "${dirC%/*}"
			zylogger -s 17 -p 6 -f 17 "[USB ${cata}] Moving ${f_i##/} from USB to Backup Folder."
			echo "mv -f ${dir_a}${f_i} ${3}${f_i}" > /dev/console
			mv -f "${dir_a}${f_i}" "${3}${f_i}"
			cpresult=$?
			chmod 777 "${3}${f_i}"
			;;
		11)
			#mv B C
			dirC="${3}${f_i}"
			echo "mkdir -p -m 777 ${dirC%/*}" > /dev/console
			mkdir -p -m 777 "${dirC%/*}"
			zylogger -s 17 -p 6 -f 17 "[USB ${cata}] Moving ${f_i##/} from Internal Volume to Backup Folder."
			echo "mv -f ${2}${f_i} ${3}${f_i}" > /dev/console
			mv -f "${2}${f_i}" "${3}${f_i}"
			cpresult=$?
			chmod 777 "${3}${f_i}"
			;;
		12)
			#one-way copy: do nothing
			echo "#zylogger -s 17 -p 6 -f 17 [USB ${cata}] Skip ${f_i##/}: File not Exist." > /dev/console
			;;
		*)
			echo "${bsname}:case_return=$case_return" >> /tmp/michael.txt
			echo -e "-1\nButton is Disabled" > /tmp/copy_sync_status.txt
			FAILEXIT 255
			;;
	esac

	if [ ${cpresult} -ne 0 ] || [ ${cpresult1} -ne 0 ]; then
		zylogger -s 17 -p 3 -f 17 "[USB ${cata}] Failed at File ${f_i##/}."
		echo -e "-1\nFailed at File ${f_i##/}" > /tmp/copy_sync_status.txt
		FAILEXIT 15
	fi
done < ${listA}

end_t=`date +%s`
elapsed_t=$(( end_t - start_t ))
if [ ${elapsed_t} -lt 0 ]; then
	elapsed_t=0
fi
zylogger -s 17 -p 6 -f 17 "[USB ${cata}] Finished. Elapsed Time ${elapsed_t} Seconds."
echo "zylogger -s 17 -p 6 -f 17 [USB ${cata}] Finished. Elapsed Time ${elapsed_t} Seconds." >> /tmp/michael.txt

if [ "${idB}" == "md0" ]; then
	idDock=`readlink /etc/zyxel/storage/sysvol|cut -d '/' -f 3`
	volname=`grep ${idDock} /etc/zyxel/storage/extuuid.table|cut -d '|' -f 1`
else
	volname=`grep ${idB} /etc/zyxel/storage/extuuid.table|cut -d '|' -f 1`
fi
if [ "${direction}" != "cp2Vol" ] && [ "${direction}" != "cp2USB" ]; then
	if [ -e /etc/zyxel/storage/usbzync.table ]; then
		path=`cat /etc/zyxel/storage/usbzync.table|cut -d '|' -f 1|cut -d '/' -f 4`
	else
		path="public"
	fi
else
	if [ -e /etc/zyxel/storage/usbcopy.table ]; then
		path=`cat /etc/zyxel/storage/usbcopy.table|cut -d '|' -f 1|cut -d '/' -f 4`
	else
		path="public"
	fi
fi
echo -e "100\n${volname}/${path}" > /tmp/copy_sync_status.txt

if [ "${1}" == "iPhone/iPodTouch" ]; then
	rm -rf /i-data/md0/.system/idevice_${idevice_uuid}
fi

echo 0 > /tmp/cpbtnd_result.return
rm -f ${btnlock}
killall -5 do_btncpy
exit 0
