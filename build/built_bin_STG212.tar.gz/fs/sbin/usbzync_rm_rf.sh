#!/bin/sh
#exit code
#1:err
#2:/tmp/stopsync.lock exist
#16:copy failed
#17:move failed
#18:delete failed

bsname=${0##/*/}
echo "${bsname}:${@}" >> /tmp/michael.txt

if [ $# -eq 4 ]; then
	backupC=1
	direction=${4}
else
	if [ $# -eq 3 ]; then
		backupC=""
		direction=${3}
	else
		echo "usage:${bsname} /e-data/12345678 /i-data/c0617e1d/share1 /i-data/c0617e1d/public/usbsync_backup_080527025400 sync2Vol|sync2USB|twoWay" > /dev/console
		exit 1
	fi
fi

if [ "${1}" == "iPhone/iPodTouch" ]; then
	idA=${1}
else
	idA=`echo ${1}|cut -d '/' -f 3`
fi
idB=`echo ${2}|cut -d '/' -f 3`

if [ "${idA}" == "" ] || [ "${idB}" == "" ]; then
	echo "${bsname}:${@} not mp" >> /tmp/michael.txt
	echo "usage:${bsname} /e-data/12345678 /i-data/c0617e1d/share1 /i-data/c0617e1d/public/usbsync_backup_080527025400 sync2Vol|sync2USB|twoWay" > /dev/console
	exit 1
fi

if [ "${idA}" == "iPhone/iPodTouch" ]; then
	if [ -d /i-data/md0/.system ]; then
		idevice_uuid=`/usr/local/btn/imobileController -l | awk '{print $4}' | awk -F: '{print $2}'`
		if [ "${idevice_uuid}" == "" ]; then
			echo "${bsname}:${@} iPhone/iPodTouch doesn't exist" >> /tmp/michael.txt
			exit 1
		fi

		idevice_dir=/i-data/md0/.system/idevice_${idevice_uuid}/.gtkpod/musicdump
		listA=/i-data/md0/.system/idevice_${idevice_uuid}/idevice_list
		listB="/i-data/md0/.system/${idB}_B.usbzync"
	else
		echo "${bsname}:${@} /i-data/md0/.system doesn't exist" >> /tmp/michael.txt
		exit 1
	fi
else
	if [ -d /i-data/md0 ]; then
		listA="/i-data/md0/.system/${idA}_A.usbzync"
		listB="/i-data/md0/.system/${idB}_B.usbzync"
	else
		listA="/tmp/${idA}_A.usbzync"
		listB="/tmp/${idB}_B.usbzync"
	fi
fi

if [ ! -e ${listA} ] || [ ! -e ${listB} ]; then
	echo "${listA}|${listB} not exist" > /dev/console
	exit 1
fi

if [ "${direction}" != "sync2Vol" ] && [ "${direction}" != "sync2USB" ]; then
	echo "wrong direction:${direction}" > /dev/console
	exit 1
fi

#sync2Vol:rm -rf for B
if [ "${direction}" == "sync2Vol" ]; then
	while read d_i; do
		#needn't this lock for iPhone/iPodTouch
		if [ "${idA}" != "iPhone/iPodTouch" ] && [ -e /tmp/stopsync.lock ]; then
			echo "${bsname}:/tmp/stopsync.lock exist" >> /tmp/michael.txt
			exit 2
		fi

		if [ "${idA}" == "iPhone/iPodTouch" ]; then
			dir_a=${idevice_dir}
		else
			dir_a=${1}
		fi

		if [ ! -e "${dir_a}${d_i}" ]; then
			if [ "${backupC}" == "1" ]; then
				dirC="${3}${d_i}"
				echo "mkdir -p -m 777 ${dirC%/*}" > /dev/console
				mkdir -p -m 777 "${dirC%/*}"
				zylogger -s 17 -p 6 -f 17 "[USB Sync] Moving ${d_i##/} from Internal Volume to Backup Folder."
				echo "mv -f ${2}${d_i} ${3}${d_i}" > /dev/console
				mv -f "${2}${d_i}" "${3}${d_i}"
				cpresult=$?
				if [ $cpresult -ne 0 ]; then
					echo "parent first moved: ${d_i##/}" >> /tmp/michael.txt
				fi
				chmod 777 -R "${3}${d_i}"
			else
				echo "rm -rf ${2}${d_i}" > /dev/console
				zylogger -s 17 -p 6 -f 17 "[USB Sync] Deleting ${d_i##/} from Internal Volume Recursively."
				rm -rf "${2}${d_i}"
				cpresult=$?
				if [ $cpresult -ne 0 ]; then
					echo "zylogger -s 17 -p 3 -f 17 [USB Sync] Sync Failed at Folder ${d_i##/}." >> /tmp/michael.txt
					zylogger -s 17 -p 3 -f 17 "[USB Sync] Sync Failed at Folder ${d_i##/}."
					exit 18
				fi
			fi
		fi
	done < ${listB}
fi

#sync2USB:rm -rf for A
if [ "${direction}" == "sync2USB" ]; then
	while read d_i; do
		if [ -e /tmp/stopsync.lock ]; then
			echo "${bsname}:/tmp/stopsync.lock exist" >> /tmp/michael.txt
			exit 2
		fi
		if [ ! -e "${2}${d_i}" ]; then
			if [ "${backupC}" == "1" ]; then
				dirC="${3}${d_i}"
				echo "mkdir -p -m 777 ${dirC%/*}" > /dev/console
				mkdir -p -m 777 "${dirC%/*}"
				zylogger -s 17 -p 6 -f 17 "[USB Sync] Moving ${d_i##/} from USB to Backup Folder."
				echo "mv -f ${1}${d_i} ${3}${d_i}" > /dev/console
				mv -f "${1}${d_i}" "${3}${d_i}"
				cpresult=$?
				if [ $cpresult -ne 0 ]; then
					echo "parent first moved: ${d_i##/}" >> /tmp/michael.txt
				fi
				chmod 777 -R "${3}${d_i}"
			else
				echo "rm -rf ${1}${d_i}" > /dev/console
				zylogger -s 17 -p 6 -f 17 "[USB Sync] Deleting ${d_i##/} from USB Recursively."
				rm -rf "${1}${d_i}"
				cpresult=$?
				if [ $cpresult -ne 0 ]; then
					echo "zylogger -s 17 -p 3 -f 17 [USB Sync] Sync Failed at Folder ${d_i##/}." >> /tmp/michael.txt
					zylogger -s 17 -p 3 -f 17 "[USB Sync] Sync Failed at Folder ${d_i##/}."
					exit 18
				fi
			fi
		fi
	done < ${listA}
fi

exit 0
