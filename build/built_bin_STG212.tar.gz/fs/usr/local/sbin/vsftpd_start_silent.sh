#!/bin/sh

# zylogger
#   source 17: built-in service
#   priority 5: notice
#   facility 17: built-in service
#
# Detailed information is in zylog-1.0/zylog.h

# This script may be called from ZySH watchdog and 
# may not check if FTPd is already running, so
# FTPd should be killed here.

/bin/killall -9 pure-ftpd

PS=`/bin/ps | /bin/grep pure-ftpd | /bin/grep -v grep`

# test if "$PS" is non-null
while [ -n "$PS" ]
do
	sleep 1
	PS=`/bin/ps | /bin/grep pure-ftpd | /bin/grep -v grep`
done


if [ -x /usr/local/sbin/pure-ftpd ] ; then
  /bin/nice -n 20 /usr/local/sbin/pure-ftpd `cat /var/zyxel/pure-ftpd.arg`
fi


