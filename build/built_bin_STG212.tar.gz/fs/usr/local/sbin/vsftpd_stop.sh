#!/bin/sh

# zylogger
#   source 17: built-in service
#   priority 5: notice
#   facility 17: built-in service
#
# Detailed information is in zylog-1.0/zylog.h

if [ "x$1" != "xgrace" ]; then
# KILL SERVER and ALL CONNECTED FTP
	/bin/killall -9 pure-ftpd > /dev/null 2>&1
	/usr/sbin/zylogger -s 17 -p 5 -f 17 "FTP server stops"
	cat /proc/mounts | grep /home/shares/ | awk '{print $2}' | sed -e 's/\\040/ /g' | sed -e 's/ (deleted)$//' | sed -e 's/^/"/g' | sed -e 's/$/"/g' | xargs umount
	cat /proc/mounts | grep /home/shares/ | awk '{print $2}' | sed -e 's/\\040/ /g' | sed -e 's/^/"/g' | sed -e 's/$/"/g' | xargs umount
	find /home/shares -type d | grep -v '^\/home\/shares$' | grep -E '^\/home\/shares\/[0-9]+' | sort -r | sed -e 's/^/"/g' | sed -e 's/$/"/g' | xargs rmdir
fi
