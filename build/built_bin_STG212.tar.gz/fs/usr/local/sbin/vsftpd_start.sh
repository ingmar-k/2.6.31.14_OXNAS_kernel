#!/bin/sh

# zylogger
#   source 17: built-in service
#   priority 5: notice
#   facility 17: built-in service
#
# Detailed information is in zylog-1.0/zylog.h

# This script may be called from ZySH watchdog and
# may not check if FTPd is already running, so
# FTPd should be killed here.

# Check whether need restart FTPd
if [ "x`cat /var/zyxel/pure-ftpd.arg`" == "x`cat /var/zyxel/pure-ftpd.arg.old`" ] && [ "`pidof pure-ftpd`" != "" ]; then
	# Needn't restart FTPd, because...
	#  1. FTPd is alive
	#  2. Arguments is the same as before
	exit 0
fi

#/bin/killall -9 pure-ftpd
FTP_PID=`cat /var/run/pure-ftpd.pid`
kill -9 ${FTP_PID} > /dev/null 2>&1

mkdir -p /home/shares
chmod 0777 /home/shares

#PS=`/bin/ps | /bin/grep pure-ftpd | /bin/grep -v grep`

# test if "$PS" is non-null
#if [ -n "$PS" ]; then
#	sleep 2
#	killall -9 pure-ftpd
#fi

# Make it start gracefully
#cat /proc/mounts | grep /home/shares/ | awk '{print $2}' | sed -e 's/\\040/ /g' | sed -e 's/ (deleted)$//' | sed -e 's/^/"/g' | sed -e 's/$/"/g' | xargs umount
#cat /proc/mounts | grep /home/shares/ | awk '{print $2}' | sed -e 's/\\040/ /g' | sed -e 's/^/"/g' | sed -e 's/$/"/g' | xargs umount
#find /home/shares -type d | grep -v '^\/home\/shares$' | grep -E '^\/home\/shares\/[0-9]+' | sort -r | sed -e 's/^/"/g' | sed -e 's/$/"/g' | xargs rmdir

if [ ! -d /etc/ssl/private ] ; then
  mkdir -p /etc/ssl/private
fi

if [ -f /etc/service_conf/CA.cer ] && [ -f /etc/service_conf/CA_key.cer ] ; then
  cat /etc/service_conf/CA.cer /etc/service_conf/CA_key.cer > /etc/ssl/private/pure-ftpd.pem
fi

if [ -x /usr/local/sbin/pure-ftpd ] && [ -f /etc/service_conf/CA_key.cer ]
then
  /bin/nice -n 20 /usr/local/sbin/pure-ftpd -Y 1 `cat /var/zyxel/pure-ftpd.arg`
  /usr/sbin/zylogger -s 17 -p 5 -f 17 "FTP server starts with TLS mode"
else
  /bin/nice -n 20 /usr/local/sbin/pure-ftpd `cat /var/zyxel/pure-ftpd.arg`
  /usr/sbin/zylogger -s 17 -p 5 -f 17 "FTP server starts with normal mode"
fi
cp -f /var/zyxel/pure-ftpd.arg /var/zyxel/pure-ftpd.arg.old


### modify by Charles.Tong on 20120523, if HDD of Seagate Model ST1500DL003-9VT1 is mount on STG-212,and 
###the uploading bandwidth of FTP is over 2000Kbytes/sec which would cause problem on STG-212.
##Start line by Charles.Tong
#HDDMODEL=`cat /proc/scsi/scsi |grep "Model"|cut -d ':' -f3 |cut -d ' ' -f2`
#FTP_UP_BW=`cat /var/zyxel/pure-ftpd.arg|grep "\-T"|cut -d "T" -f2|cut -d':' -f1`
#FTP_DL_BW=`cat /var/zyxel/pure-ftpd.arg|grep "\-T"|cut -d "T" -f2|cut -d':' -f2|cut -d' ' -f1`
#if [ -x /usr/local/sbin/pure-ftpd ] && [ -f /etc/service_conf/CA_key.cer ]
#then
#  if [ "$HDDMODEL" = "ST1500DL003-9VT1" ] && [ !$FTP_UP_BW ] && [ $FTP_DL_BW ]
#  then
#  C1=`cat /var/zyxel/pure-ftpd.arg|cut -d'I' -f1`
#  C2="I"
#  C3=`cat /var/zyxel/pure-ftpd.arg|cut -d'I' -f2|cut -d' ' -f2`
#  C4="-T 2000:"$FTP_DL_BW" -E"
#  echo "$C1$C2 $C3 $C4" >/var/zyxel/pure-ftpd.arg.tem
#  cp -f /var/zyxel/pure-ftpd.arg.tem  /var/zyxel/pure-ftpd.arg
  
#  elif [ "$HDDMODEL" = "ST1500DL003-9VT1" ] && [ !$FTP_UP_BW ] && [ !$FTP_DL_BW ]
#  then
#  `cat /var/zyxel/pure-ftpd.arg|sed 's/ -E/ -T 2000: -E/g'>/var/zyxel/pure-ftpd.arg`
  
#  elif [ "$HDDMODEL" = "ST1500DL003-9VT1" ] && [ $FTP_UP_BW -gt 2000 ]
#  then
#  `cat /var/zyxel/pure-ftpd.arg|grep "\-T"|sed 's/'"$FTP_UP_BW"'/ '"2000"'/g'>/var/zyxel/pure-ftpd.arg` 
#  fi   
#  /bin/nice -n 20 /usr/local/sbin/pure-ftpd -Y 1 `cat /var/zyxel/pure-ftpd.arg`
#  /usr/sbin/zylogger -s 17 -p 5 -f 17 "FTP server starts with TLS mode"
#else
# if [ "$HDDMODEL" = "ST1500DL003-9VT1" ] && [ !$FTP_UP_BW ] && [ $FTP_DL_BW ]
# then
# C1=`cat /var/zyxel/pure-ftpd.arg|cut -d'I' -f1`
# C2="I"
# C3=`cat /var/zyxel/pure-ftpd.arg|cut -d'I' -f2|cut -d' ' -f2`
# C4="-T 2000:"$FTP_DL_BW" -E"
# echo "$C1$C2 $C3 $C4" >/var/zyxel/pure-ftpd.arg.tem
# cp -f /var/zyxel/pure-ftpd.arg.tem  /var/zyxel/pure-ftpd.arg
 
# elif [ "$HDDMODEL" = "ST1500DL003-9VT1" ] && [ !$FTP_UP_BW ] && [ !$FTP_DL_BW ]
# then
# `cat /var/zyxel/pure-ftpd.arg|sed 's/ -E/ -T 2000: -E/g'>/var/zyxel/pure-ftpd.arg`
# 
# elif [ "$HDDMODEL" = "ST1500DL003-9VT1" ] && [ $FTP_UP_BW -gt 2000 ]
# then
# `cat /var/zyxel/pure-ftpd.arg|grep "\-T"|sed 's/'"$FTP_UP_BW"'/ 2000/g'>/var/zyxel/pure-ftpd.arg`
# fi
#  /bin/nice -n 20 /usr/local/sbin/pure-ftpd `cat /var/zyxel/pure-ftpd.arg`
#  /usr/sbin/zylogger -s 17 -p 5 -f 17 "FTP server starts with normal mode"
#fi
#cp -f /var/zyxel/pure-ftpd.arg /var/zyxel/pure-ftpd.arg.old
##End line by Charles.Tong


