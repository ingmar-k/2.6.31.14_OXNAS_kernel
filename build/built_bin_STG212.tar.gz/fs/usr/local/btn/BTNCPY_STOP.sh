#!/bin/sh
killall cp
killall do_btncpy

done=`ps|grep do_btncpy|grep -v grep`
count=0
while [ $count -le 10 ] && [ "${done}" != "" ]; do
	killall -9 do_btncpy
	done=`ps|grep do_btncpy|grep -v grep`
	sleep 1
   	let "count = $count + 1"
done

#just in case
killall -9 cp
