#!/bin/sh
bsname=${0##/*/}

#find /sys/devices/platform/oxnas-ehci.0/usb1/1-1/1-1.2/ -maxdepth 3 -name "host*"
allsdx=`sg_map -x -i|awk '{print $7}'|cut -c 6-8`
for sdx in ${allsdx}; do
	ejected=`cat /proc/mounts|grep "/dev/${sdx}"`
	if [ "${ejected}" == "" ] ; then
		echo "${bsname}:skip /dev/${sdx}" > /dev/console
		continue
	fi

	atfront=`readlink /sys/block/${sdx}|grep "oxnas-ehci.0/usb1/1-1/1-1.2"`
	#sdcard=`readlink /sys/block/${sdx}|grep "oxnas-ehci.0/usb1/1-1/1-1.3"`
	#if [ "${atfront}" != "" ] || [ "${sdcard}" != "" ]; then
	if [ "${atfront}" != "" ]; then
		#start removal
		setLED EJECT GREEN BLINK
		echo "${bsname}:zyshclient -p 150 -e \"storage ejectEDisk USB1 /dev/${sdx}\"" > /dev/console
		zyshclient -p 150 -e "storage ejectEDisk USB1 /dev/${sdx}"
		#end removal
		setLED EJECT GREEN ON
	else
		echo "${bsname}:skip /dev/${sdx}" > /dev/console
	fi
done
