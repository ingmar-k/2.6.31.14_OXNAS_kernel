#!/bin/sh

done=`ps|grep do_btncpy|grep -v grep`

if [ "${done}" == "" ]; then
	/bin/nice -n 20 /usr/local/btn/do_btncpy
fi
