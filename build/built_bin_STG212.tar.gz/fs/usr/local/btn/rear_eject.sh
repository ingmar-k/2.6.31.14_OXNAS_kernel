#!/bin/sh
bsname=${0##/*/}

#find /sys/devices/platform/oxnas-ehci.0/usb1/1-1/1-1.2/ -maxdepth 3 -name "host*"
allsdx=`sg_map -x -i|awk '{print $7}'|cut -c 6-8`
for sdx in ${allsdx}; do
	ejected=`cat /proc/mounts|grep "/dev/${sdx}"`
	if [ "${ejected}" == "" ] ; then
		echo "${bsname}:skip /dev/${sdx}" > /dev/console
		continue
	fi

	atrear=`readlink /sys/block/${sdx}|grep "oxnas-ehci.0/usb1/1-1/1-1.4"`
	if [ "${atrear}" != "" ]; then
		#start removal
		setLED EJECT GREEN BLINK
		echo "${bsname}:zyshclient -p 150 -e \"storage ejectEDisk USB2 /dev/${sdx}\"" > /dev/console
		zyshclient -p 150 -e "storage ejectEDisk USB2 /dev/${sdx}"
		#end removal
		setLED EJECT GREEN ON
	else
		echo "${bsname}:skip /dev/${sdx}" > /dev/console
	fi
done


