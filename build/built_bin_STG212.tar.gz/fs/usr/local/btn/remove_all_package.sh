#!/bin/sh

INSTALLED_PKGS="/tmp/pkgs"
pkgsInstalled=""

# reset all package configs
touch /tmp/PKG_RESET

# save all package names to file "${INSTALLED_PKGS}"
/usr/bin/ipkg-cl -f /etc/zyxel/zy-pkg.conf -t /usr/local/zy-pkgs/tmp list | egrep "(pkgName:)|(status:)" > ${INSTALLED_PKGS}

# retrieve installed packages to "pkgsInstalled"
while read line ; do
	foundpkg="`echo ${line} | grep "^pkgName:" | awk -F' ' '{print $2}'`"
	if [ "${foundpkg}" = "" ]; then
		pkgstatus="`echo ${line} | grep "status:" | awk -F' ' '{print $2}'`"
		if [ "${pkgstatus}" = "Built-in" ]; then
		pkgsInstalled="${pkgsInstalled} ${pkgname}"
		elif [ "${pkgstatus}" = "Enabled" ]; then
		pkgsInstalled="${pkgsInstalled} ${pkgname}"
		elif [ "${pkgstatus}" = "Disabled" ]; then
		pkgsInstalled="${pkgsInstalled} ${pkgname}"
		fi
	else
		pkgname="${foundpkg}"
	fi
done < ${INSTALLED_PKGS}

# write installed packages into PKG_RESET file
echo ${pkgsInstalled} > /tmp/PKG_RESET

# uninstall all installed packages
if [ "${pkgsInstalled}" != "" ]; then
	echo "*** package to be removed: ${pkgsInstalled}"
	/usr/bin/ipkg-cl -f /etc/zyxel/zy-pkg.conf -t /usr/local/zy-pkgs/tmp -recursive remove ${pkgsInstalled}
else
	echo "*** no package installed now ***"
fi

# remove all zpkg files and ZYPKGS in admin/zy-pkgs
rm -rf /i-data/md0/admin/package/*
rm -rf /usr/local/zy-pkgs/*
