#!/bin/sh

zyshclient -p 150 -e "configure terminal ip smb user \"admin\""
zyshclient -p 150 -e "configure terminal ip smb user \"admin\" 501 password B757BF5C0D87772FAAD3B435B51404EE:7CE21F17C0AEE7FB9CEBA532D0546AD6"
zyshclient -p 150 -e "configure terminal ip smb user \"admin\" 501 type admin"
zyshclient -p 150 -e "configure terminal ip smb user \"admin\" 501 shpass \$1\$\$iC.dUsGpxNNJGeOm1dFio/"
zyshclient -p 150 -e "configure terminal ip smb user \"admin\" 501 exit"
zyshclient -p 150 -e "configure terminal interface ge1"
zyshclient -p 150 -e "configure terminal interface ge1 ip address dhcp"
zyshclient -p 150 -e "configure terminal interface ge1 mtu 1500"
zyshclient -p 150 -e "configure terminal interface ge1 exit"
zyshclient -p 150 -e "exit"
zyshclient -p 150 -e "configure terminal ip name-server fetch auto"
zyshclient -p 150 -e "write"

#restore LED status
setLED SYS BLUE ON
