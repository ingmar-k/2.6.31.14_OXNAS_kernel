#!/bin/sh

# Medion want to delete all packages also
/usr/local/btn/remove_all_package.sh

rm -rf /i-data/md0/.media/twonkymedia
rm -rf /etc/zyxel/conf
rm -rf /etc/zyxel/
reboot
